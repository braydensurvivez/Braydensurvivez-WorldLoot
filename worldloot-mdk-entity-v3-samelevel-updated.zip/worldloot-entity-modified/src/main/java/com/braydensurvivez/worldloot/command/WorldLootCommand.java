package com.braydensurvivez.worldloot.command;

import com.braydensurvivez.worldloot.WorldLootMod;
import com.braydensurvivez.worldloot.data.GlobalAssignmentData;
import com.braydensurvivez.worldloot.data.TurnBackTimeData;
import com.braydensurvivez.worldloot.entity.EntitySpawnDebugData;
import com.braydensurvivez.worldloot.entity.EntitySpawnEngine;
import com.braydensurvivez.worldloot.entity.EntitySpawnRule;
import com.braydensurvivez.worldloot.entity.EntitySpawnRuleData;
import com.braydensurvivez.worldloot.loot.DeployEngine;
import com.braydensurvivez.worldloot.loot.TurnBackTimeEngine;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;

import java.util.List;
import java.util.Map;

/**
 * Command layout:
 *
 *   /braydensurvivezloot deploy                            – fill all loaded containers (all pools)
 *   /braydensurvivezloot deploy force                      – same, re-fill already-populated ones too
 *   /braydensurvivezloot deploy <block> <pool>             – targeted, currently loaded chunks
 *   /braydensurvivezloot deploy force <block> <pool>       – force-targeted
 *   /braydensurvivezloot deploy global <block> <pool>      – register passive chunk-load assignment
 *   /braydensurvivezloot deploy global list                – list all active global assignments
 *
 *   /braydensurvivezloot remove global <block> <pool>      – remove a specific global assignment
 *
 *   /braydensurvivezloot reset                             – clear populated-tracking data
 *   /braydensurvivezloot pools                             – list loot pool names
 *
 *   ── Entity spawn system ──────────────────────────────────────────────────
 *
 *   /braydensurvivezloot entity deploy global <min> <max> <pool>
 *       Register a global entity spawn rule. Entities from <pool> will be
 *       spawned when the server has between <min> and <max> loaded chunks.
 *
 *   /braydensurvivezloot entity deploy global list
 *       List all active entity spawn rules.
 *
 *   /braydensurvivezloot entity remove global <min> <max> <pool>
 *       Remove a specific entity spawn rule.
 *
 *   /braydensurvivezloot entity spawn <pool>
 *       Manually trigger one spawn from the given entity pool (default distance 3-6 chunks).
 *
 *   /braydensurvivezloot entity spawn <pool> <minChunks> <maxChunks>
 *       Same, but spawn exactly minChunks–maxChunks chunks away from you.
 *
 *   /braydensurvivezloot entity pools
 *       List all available entity spawn pool names.
 */
public class WorldLootCommand {

    private static DeployEngine engine;

    private static DeployEngine getEngine() {
        if (engine == null) engine = new DeployEngine();
        return engine;
    }

    // Tab-complete: loot pool names from config
    private static final SuggestionProvider<CommandSourceStack> SUGGEST_POOLS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(getEngine().getPoolNames(), builder);

    // Tab-complete: entity pool names
    private static final SuggestionProvider<CommandSourceStack> SUGGEST_ENTITY_POOLS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(
                    WorldLootMod.getEntitySpawnPoolRegistry().getPoolNames(), builder);

    // Tab-complete: block IDs that already have a global assignment
    private static final SuggestionProvider<CommandSourceStack> SUGGEST_ASSIGNED_BLOCKS =
            (ctx, builder) -> {
                MinecraftServer server = ctx.getSource().getServer();
                if (server == null) return builder.buildFuture();
                return SharedSuggestionProvider.suggest(
                        GlobalAssignmentData.get(server.overworld()).getAll().keySet(), builder);
            };

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("braydensurvivezloot")
                .requires(src -> src.hasPermission(2))

                // ── deploy ────────────────────────────────────────────────
                .then(Commands.literal("deploy")

                    // deploy global …
                    .then(Commands.literal("global")

                        // deploy global list
                        .then(Commands.literal("list")
                            .executes(WorldLootCommand::globalList))

                        // deploy global <block> <pool>
                        .then(Commands.argument("block", StringArgumentType.string())
                            .then(Commands.argument("pool", StringArgumentType.string())
                                .suggests(SUGGEST_POOLS)
                                .executes(WorldLootCommand::deployGlobal))))

                    // deploy force [<block> <pool>]
                    .then(Commands.literal("force")
                        .then(Commands.argument("block", StringArgumentType.string())
                            .then(Commands.argument("pool", StringArgumentType.string())
                                .suggests(SUGGEST_POOLS)
                                .executes(WorldLootCommand::deployTargetedForce)))
                        .executes(WorldLootCommand::deployForce))

                    // deploy <block> <pool>
                    .then(Commands.argument("block", StringArgumentType.string())
                        .then(Commands.argument("pool", StringArgumentType.string())
                            .suggests(SUGGEST_POOLS)
                            .executes(WorldLootCommand::deployTargeted)))

                    // deploy  (no args)
                    .executes(WorldLootCommand::deploy))

                // ── remove ────────────────────────────────────────────────
                .then(Commands.literal("remove")

                    // remove global <block> <pool>
                    .then(Commands.literal("global")
                        .then(Commands.argument("block", StringArgumentType.string())
                            .suggests(SUGGEST_ASSIGNED_BLOCKS)
                            .then(Commands.argument("pool", StringArgumentType.string())
                                .suggests(SUGGEST_POOLS)
                                .executes(WorldLootCommand::removeGlobal)))))

                // ── reset ─────────────────────────────────────────────────
                .then(Commands.literal("reset")
                    .executes(WorldLootCommand::reset))

                // ── pools ─────────────────────────────────────────────────
                .then(Commands.literal("pools")
                    .executes(WorldLootCommand::listPools))

                // ── turnbacktime ──────────────────────────────────────────
                .then(Commands.literal("turnbacktime")

                    .then(Commands.literal("global")

                        .then(Commands.literal("status")
                            .executes(WorldLootCommand::turnBackTimeGlobalStatus))

                        .executes(WorldLootCommand::turnBackTimeGlobalToggle))

                    .then(Commands.argument("radius", IntegerArgumentType.integer(1, 512))
                        .executes(WorldLootCommand::turnBackTimeRadius))

                    .executes(WorldLootCommand::turnBackTime))

                // ── entity ────────────────────────────────────────────────
                .then(Commands.literal("entity")

                    // entity deploy global <min> <max> <pool>
                    .then(Commands.literal("deploy")
                        .then(Commands.literal("global")

                            // entity deploy global list
                            .then(Commands.literal("list")
                                .executes(WorldLootCommand::entityRuleList))

                            // entity deploy global <min> <max> <pool>
                            .then(Commands.argument("min", IntegerArgumentType.integer(1))
                                .then(Commands.argument("max", IntegerArgumentType.integer(1))
                                    .then(Commands.argument("pool", StringArgumentType.string())
                                        .suggests(SUGGEST_ENTITY_POOLS)
                                        .executes(WorldLootCommand::entityDeployGlobal))))))

                    // entity remove global <min> <max> <pool>
                    .then(Commands.literal("remove")
                        .then(Commands.literal("global")
                            .then(Commands.argument("min", IntegerArgumentType.integer(1))
                                .then(Commands.argument("max", IntegerArgumentType.integer(1))
                                    .then(Commands.argument("pool", StringArgumentType.string())
                                        .suggests(SUGGEST_ENTITY_POOLS)
                                        .executes(WorldLootCommand::entityRemoveGlobal))))))

                    // entity spawn <pool> [<minChunks> <maxChunks>]
                    .then(Commands.literal("spawn")
                        .then(Commands.argument("pool", StringArgumentType.string())
                            .suggests(SUGGEST_ENTITY_POOLS)
                            // Optional distance arguments
                            .then(Commands.argument("minChunks", IntegerArgumentType.integer(1, 32))
                                .then(Commands.argument("maxChunks", IntegerArgumentType.integer(1, 32))
                                    .executes(WorldLootCommand::entitySpawnManualDistance)))
                            .executes(WorldLootCommand::entitySpawnManual)))

                    // entity pools
                    .then(Commands.literal("pools")
                        .executes(WorldLootCommand::entityListPools))

                    // entity debug  (toggle debug mode on/off)
                    .then(Commands.literal("debug")
                        .executes(WorldLootCommand::entityDebugToggle)))
        );
    }

    // ── Manual loot deploy ─────────────────────────────────────────────────────

    private static int deploy(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        src.sendSuccess(() -> Component.literal("[WorldLoot] Starting deployment scan…"), true);
        DeployEngine.DeployResult r = getEngine().deploy(src.getServer(), false);
        src.sendSuccess(() -> Component.literal(formatResult(r, false, null, null)), true);
        return 1;
    }

    private static int deployForce(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        src.sendSuccess(() -> Component.literal("[WorldLoot] Starting FORCE deployment scan…"), true);
        DeployEngine.DeployResult r = getEngine().deploy(src.getServer(), true);
        src.sendSuccess(() -> Component.literal(formatResult(r, true, null, null)), true);
        return 1;
    }

    private static int deployTargeted(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();
        if (!validatePool(src, pool)) return 0;
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot] Targeting block='" + block + "' pool='" + pool + "'…"), true);
        DeployEngine.DeployResult r = getEngine().deployTargeted(src.getServer(), false, block, pool);
        src.sendSuccess(() -> Component.literal(formatResult(r, false, block, pool)), true);
        return 1;
    }

    private static int deployTargetedForce(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();
        if (!validatePool(src, pool)) return 0;
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot] FORCE targeting block='" + block + "' pool='" + pool + "'…"), true);
        DeployEngine.DeployResult r = getEngine().deployTargeted(src.getServer(), true, block, pool);
        src.sendSuccess(() -> Component.literal(formatResult(r, true, block, pool)), true);
        return 1;
    }

    // ── Global loot assignment ─────────────────────────────────────────────────

    private static int deployGlobal(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();

        if (!validatePool(src, pool)) return 0;

        GlobalAssignmentData data = GlobalAssignmentData.get(src.getServer().overworld());
        String previous = data.getPool(block);
        data.assign(block, pool);

        if (previous != null) {
            src.sendSuccess(() -> Component.literal(String.format(
                    "[WorldLoot] Global assignment UPDATED: '%s' was '%s', now '%s'.",
                    block, previous, pool)), true);
        } else {
            src.sendSuccess(() -> Component.literal(String.format(
                    "[WorldLoot] Global assignment SET: '%s' → '%s'.", block, pool)), true);
        }
        return 1;
    }

    private static int removeGlobal(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();

        GlobalAssignmentData data = GlobalAssignmentData.get(src.getServer().overworld());
        String current = data.getPool(block);

        if (current == null) {
            src.sendFailure(Component.literal(String.format(
                    "[WorldLoot] No global assignment exists for '%s'.", block)));
            return 0;
        }

        if (!current.equalsIgnoreCase(pool.trim())) {
            src.sendFailure(Component.literal(String.format(
                    "[WorldLoot] Pool mismatch: '%s' is currently assigned to '%s', not '%s'.",
                    block, current, pool)));
            return 0;
        }

        data.remove(block);
        src.sendSuccess(() -> Component.literal(String.format(
                "[WorldLoot] Global assignment REMOVED: '%s' → '%s'.", block, pool)), true);
        return 1;
    }

    private static int globalList(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        Map<String, String> all = GlobalAssignmentData.get(src.getServer().overworld()).getAll();
        if (all.isEmpty()) {
            src.sendSuccess(() -> Component.literal(
                    "[WorldLoot] No global assignments active."), false);
        } else {
            StringBuilder sb = new StringBuilder("[WorldLoot] Active global assignments (").append(all.size()).append("):\n");
            all.forEach((b, p) -> sb.append("  ").append(b).append("  →  ").append(p).append("\n"));
            src.sendSuccess(() -> Component.literal(sb.toString().trim()), false);
        }
        return 1;
    }

    // ── Reset ──────────────────────────────────────────────────────────────────

    private static int reset(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        getEngine().reset(src.getServer());
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot] Tracking cleared. All containers eligible for next deploy."), true);
        return 1;
    }

    // ── List pools ─────────────────────────────────────────────────────────────

    private static int listPools(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        String names = String.join(", ", getEngine().getPoolNames());
        src.sendSuccess(() -> Component.literal("[WorldLoot] Available loot pools: " + names), false);
        return 1;
    }

    // ── Entity spawn commands ──────────────────────────────────────────────────

    /**
     * /braydensurvivezloot entity deploy global <min> <max> <pool>
     *
     * Registers a rule: whenever loaded chunk count is in [min, max],
     * the tick handler spawns an entity from the named pool.
     */
    private static int entityDeployGlobal(CommandContext<CommandSourceStack> ctx) {
        int    min  = IntegerArgumentType.getInteger(ctx, "min");
        int    max  = IntegerArgumentType.getInteger(ctx, "max");
        String pool = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();

        if (!validateEntityPool(src, pool)) return 0;

        if (min > max) {
            src.sendFailure(Component.literal(
                    "[WorldLoot/Entity] min (" + min + ") must be ≤ max (" + max + ")."));
            return 0;
        }

        EntitySpawnRuleData data = EntitySpawnRuleData.get(src.getServer().overworld());
        data.addRule(new EntitySpawnRule(min, max, pool));

        src.sendSuccess(() -> Component.literal(String.format(
                "[WorldLoot/Entity] Spawn rule ADDED: pool='%s' fires when loaded chunks are in [%d, %d]. " +
                "Entities will spawn a few chunks away from a random online player every 5 seconds " +
                "while the chunk count condition is met.",
                pool, min, max)), true);
        return 1;
    }

    /**
     * /braydensurvivezloot entity deploy global list
     */
    private static int entityRuleList(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        List<EntitySpawnRule> rules = EntitySpawnRuleData.get(src.getServer().overworld()).getRules();
        if (rules.isEmpty()) {
            src.sendSuccess(() -> Component.literal(
                    "[WorldLoot/Entity] No entity spawn rules active. " +
                    "Use: /braydensurvivezloot entity deploy global <min> <max> <pool>"), false);
        } else {
            StringBuilder sb = new StringBuilder("[WorldLoot/Entity] Active entity spawn rules (")
                    .append(rules.size()).append("):\n");
            for (int i = 0; i < rules.size(); i++) {
                EntitySpawnRule r = rules.get(i);
                sb.append("  [").append(i).append("] chunks=[")
                  .append(r.minChunks).append("-").append(r.maxChunks)
                  .append("]  pool='").append(r.poolName).append("'\n");
            }
            sb.append("Remove with: /braydensurvivezloot entity remove global <min> <max> <pool>");
            src.sendSuccess(() -> Component.literal(sb.toString().trim()), false);
        }
        return 1;
    }

    /**
     * /braydensurvivezloot entity remove global <min> <max> <pool>
     */
    private static int entityRemoveGlobal(CommandContext<CommandSourceStack> ctx) {
        int    min  = IntegerArgumentType.getInteger(ctx, "min");
        int    max  = IntegerArgumentType.getInteger(ctx, "max");
        String pool = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();

        EntitySpawnRuleData data = EntitySpawnRuleData.get(src.getServer().overworld());
        boolean removed = data.removeRule(min, max, pool);

        if (removed) {
            src.sendSuccess(() -> Component.literal(String.format(
                    "[WorldLoot/Entity] Spawn rule REMOVED: pool='%s' chunks=[%d-%d].", pool, min, max)), true);
        } else {
            src.sendFailure(Component.literal(String.format(
                    "[WorldLoot/Entity] No matching rule found for pool='%s' chunks=[%d-%d]. " +
                    "Use /braydensurvivezloot entity deploy global list to see active rules.", pool, min, max)));
        }
        return removed ? 1 : 0;
    }

    /**
     * /braydensurvivezloot entity spawn <pool>
     *
     * Manually trigger one entity spawn from the given pool using the default
     * chunk distance (3–6 chunks from a random player).
     */
    private static int entitySpawnManual(CommandContext<CommandSourceStack> ctx) {
        String pool = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();
        if (!validateEntityPool(src, pool)) return 0;
        ServerLevel level = src.getLevel();
        boolean debugOn = EntitySpawnDebugData.get(level.getServer().overworld()).isDebugEnabled();
        EntitySpawnEngine.SpawnResult result = EntitySpawnEngine.spawnFromPool(
                level, WorldLootMod.getEntitySpawnPoolRegistry(), pool, debugOn);
        return sendSpawnResult(src, pool, result);
    }

    /**
     * /braydensurvivezloot entity spawn <pool> <minChunks> <maxChunks>
     *
     * Manually trigger one entity spawn at a specific chunk distance from you.
     * minChunks and maxChunks control how close/far the entity appears.
     * Example: "entity spawn zombies 1 2" spawns 1–2 chunks away (very close).
     */
    private static int entitySpawnManualDistance(CommandContext<CommandSourceStack> ctx) {
        String pool     = StringArgumentType.getString(ctx, "pool");
        int    minChunks = IntegerArgumentType.getInteger(ctx, "minChunks");
        int    maxChunks = IntegerArgumentType.getInteger(ctx, "maxChunks");
        CommandSourceStack src = ctx.getSource();

        if (!validateEntityPool(src, pool)) return 0;

        if (minChunks > maxChunks) {
            src.sendFailure(Component.literal(
                    "[WorldLoot/Entity] minChunks (" + minChunks +
                    ") must be ≤ maxChunks (" + maxChunks + ")."));
            return 0;
        }

        ServerLevel level = src.getLevel();
        boolean debugOn = EntitySpawnDebugData.get(level.getServer().overworld()).isDebugEnabled();
        EntitySpawnEngine.SpawnResult result = EntitySpawnEngine.spawnFromPool(
                level, WorldLootMod.getEntitySpawnPoolRegistry(), pool, debugOn, minChunks, maxChunks);
        return sendSpawnResult(src, pool, result);
    }

    /**
     * Shared feedback formatter used by both spawn command variants.
     */
    private static int sendSpawnResult(CommandSourceStack src, String pool,
                                       EntitySpawnEngine.SpawnResult result) {
        if (result.success) {
            double pct = result.pool.chancePercent(result.entry);
            int cx = result.spawnPos.getX() >> 4;
            int cz = result.spawnPos.getZ() >> 4;

            src.sendSuccess(() -> Component.literal(String.format(
                    "§a[WorldLoot/Entity] Spawned §f%s §7(%s §8%.1f%%) §7from pool §f%s§7.\n" +
                    "§7Position: §f%d %d %d §8(chunk %d, %d) §7— §f%d §7chunks from §f%s",
                    result.entityId,
                    result.pool.rarityLabel(result.entry), pct,
                    pool,
                    result.spawnPos.getX(), result.spawnPos.getY(), result.spawnPos.getZ(),
                    cx, cz,
                    result.chunkDistance,
                    result.nearestPlayer.getName().getString()
            )), true);
        } else {
            src.sendFailure(Component.literal(
                    "§c[WorldLoot/Entity] Spawn FAILED from pool '" + pool +
                    "': " + result.failReason));
        }
        return result.success ? 1 : 0;
    }

    /**
     * /braydensurvivezloot entity debug
     *
     * Toggles debug mode on/off. When ON:
     *   - All online operators receive a rich chat message on every spawn
     *     showing entity type, rarity %, pool, world position, chunk coords,
     *     and chunk distance from the nearest player.
     *   - A particle column (ENCHANT + SOUL_FIRE_FLAME) highlights the spawn
     *     chunk so it is visible from a distance.
     * When OFF: silent operation, server log only.
     */
    private static int entityDebugToggle(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        MinecraftServer server = src.getServer();
        if (server == null) {
            src.sendFailure(Component.literal("[WorldLoot/Entity] No server available."));
            return 0;
        }

        EntitySpawnDebugData data = EntitySpawnDebugData.get(server.overworld());
        boolean nowEnabled = data.toggle();

        if (nowEnabled) {
            src.sendSuccess(() -> Component.literal(
                    "§a[WorldLoot/Entity] Debug mode ENABLED.\n" +
                    "§7All ops will receive spawn notifications in chat.\n" +
                    "§7Spawned mobs will have the §aGlowing§7 effect (visible through walls, 5 min).\n" +
                    "§7Toggle off with /braydensurvivezloot entity debug"), true);
        } else {
            src.sendSuccess(() -> Component.literal(
                    "§c[WorldLoot/Entity] Debug mode DISABLED. Silent operation resumed."), true);
        }
        return 1;
    }

    /**
     * /braydensurvivezloot entity pools
     */
    private static int entityListPools(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        String names = String.join(", ", WorldLootMod.getEntitySpawnPoolRegistry().getPoolNames());
        if (names.isEmpty()) names = "(none loaded — check config/worldloot/entitypools/)";
        final String display = names;
        src.sendSuccess(() -> Component.literal("[WorldLoot/Entity] Available entity spawn pools: " + display), false);
        return 1;
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private static boolean validatePool(CommandSourceStack src, String pool) {
        if (!getEngine().getPoolNames().contains(pool)) {
            src.sendFailure(Component.literal(
                    "[WorldLoot] Unknown pool '" + pool + "'. Use /braydensurvivezloot pools to list available pools."));
            return false;
        }
        return true;
    }

    private static boolean validateEntityPool(CommandSourceStack src, String pool) {
        if (!WorldLootMod.getEntitySpawnPoolRegistry().getPoolNames().contains(pool)) {
            src.sendFailure(Component.literal(
                    "[WorldLoot/Entity] Unknown entity pool '" + pool +
                    "'. Use /braydensurvivezloot entity pools to list available pools."));
            return false;
        }
        return true;
    }

    private static String formatResult(DeployEngine.DeployResult r, boolean force,
                                       String block, String pool) {
        String prefix = force ? "Force deploy" : "Deploy";
        String target = (block != null) ? " [" + block + " / " + pool + "]" : "";
        return String.format(
                "[WorldLoot] %s%s complete. Dims:%d Chunks:%d Found:%d Populated:%d Skipped:%d BadIDs:%d",
                prefix, target,
                r.dimensionsScanned, r.chunksScanned,
                r.containersFound, r.containersPopulated,
                r.containersSkipped, r.invalidRegistryEntries);
    }

    // ── TurnBackTime ────────────────────────────────────────────────────────────

    private static final int DEFAULT_RADIUS = 64;

    private static int turnBackTime(CommandContext<CommandSourceStack> ctx) {
        return runTurnBackTime(ctx, DEFAULT_RADIUS);
    }

    private static int turnBackTimeRadius(CommandContext<CommandSourceStack> ctx) {
        int radius = IntegerArgumentType.getInteger(ctx, "radius");
        return runTurnBackTime(ctx, radius);
    }

    private static int runTurnBackTime(CommandContext<CommandSourceStack> ctx, int radius) {
        CommandSourceStack src = ctx.getSource();
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot/TurnBackTime] Scanning for player-placed vines and leaves within "
                + radius + " blocks…"), true);

        ServerLevel level = src.getLevel();
        BlockPos center = BlockPos.containing(src.getPosition());
        TurnBackTimeEngine.ClearResult result = TurnBackTimeEngine.clearRadius(level, center, radius);

        src.sendSuccess(() -> Component.literal(String.format(
                "[WorldLoot/TurnBackTime] Done. Removed %d player-placed vine/leaf blocks within %d blocks.",
                result.blocksRemoved, radius)), true);
        return 1;
    }

    private static int turnBackTimeGlobalToggle(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        MinecraftServer server = src.getServer();
        if (server == null) {
            src.sendFailure(Component.literal("[WorldLoot/TurnBackTime] No server available."));
            return 0;
        }
        TurnBackTimeData data = TurnBackTimeData.get(server.overworld());
        boolean nowEnabled = !data.isGlobalEnabled();
        data.setGlobalEnabled(nowEnabled);

        if (nowEnabled) {
            src.sendSuccess(() -> Component.literal(
                    "[WorldLoot/TurnBackTime] Global sweeper ENABLED."), true);
        } else {
            src.sendSuccess(() -> Component.literal(
                    "[WorldLoot/TurnBackTime] Global sweeper DISABLED."), true);
        }
        return 1;
    }

    private static int turnBackTimeGlobalStatus(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        MinecraftServer server = src.getServer();
        if (server == null) {
            src.sendFailure(Component.literal("[WorldLoot/TurnBackTime] No server available."));
            return 0;
        }
        TurnBackTimeData data = TurnBackTimeData.get(server.overworld());
        boolean enabled = data.isGlobalEnabled();
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot/TurnBackTime] Global sweeper is currently " +
                (enabled ? "ENABLED" : "DISABLED") + "."), false);
        return 1;
    }
}

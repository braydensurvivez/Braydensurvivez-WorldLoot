package com.braydensurvivez.worldloot.entity;

import net.minecraft.resources.ResourceLocation;

/**
 * One entry in an entity spawn pool.
 * entityId : registry name of the entity type  (e.g. "minecraft:zombie")
 * weight   : relative spawn chance (higher = more common)
 */
public class EntitySpawnEntry {
    public final ResourceLocation entityId;
    public final int weight;

    public EntitySpawnEntry(ResourceLocation entityId, int weight) {
        this.entityId = entityId;
        this.weight   = weight;
    }
}

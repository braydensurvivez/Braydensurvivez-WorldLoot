package com.braydensurvivez.worldloot.entity;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Persists the entity-spawn debug toggle across server restarts.
 *
 * When debug mode is ON every successful spawn broadcasts a detailed chat
 * message to all online operators and highlights the spawn chunk with
 * a particle column.
 *
 * Toggled by:  /braydensurvivezloot entity debug
 * Stored in:   world/data/worldloot_entity_debug.dat
 */
public class EntitySpawnDebugData extends SavedData {

    private static final String DATA_NAME = WorldLootMod.MOD_ID + "_entity_debug";

    private boolean debugEnabled = false;

    // ── Factory ────────────────────────────────────────────────────────────────

    public static EntitySpawnDebugData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(
                EntitySpawnDebugData::load,
                EntitySpawnDebugData::new,
                DATA_NAME
        );
    }

    public EntitySpawnDebugData() { }

    private static EntitySpawnDebugData load(CompoundTag tag) {
        EntitySpawnDebugData data = new EntitySpawnDebugData();
        data.debugEnabled = tag.getBoolean("debugEnabled");
        return data;
    }

    // ── Save ───────────────────────────────────────────────────────────────────

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("debugEnabled", debugEnabled);
        return tag;
    }

    // ── API ────────────────────────────────────────────────────────────────────

    public boolean isDebugEnabled() { return debugEnabled; }

    public boolean toggle() {
        debugEnabled = !debugEnabled;
        setDirty();
        return debugEnabled;
    }

    public void setDebugEnabled(boolean value) {
        debugEnabled = value;
        setDirty();
    }
}

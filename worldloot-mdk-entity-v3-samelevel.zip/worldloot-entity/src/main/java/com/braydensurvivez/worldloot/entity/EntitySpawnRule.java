package com.braydensurvivez.worldloot.entity;

/**
 * One registered global entity spawn rule:
 *   /braydensurvivezworldloot deploy global <minChunks> <maxChunks> <pool>
 *
 * The tick handler fires a spawn from this rule when the number of loaded chunks
 * is between minChunks and maxChunks (inclusive).
 */
public class EntitySpawnRule {

    public final int    minChunks;
    public final int    maxChunks;
    public final String poolName;

    public EntitySpawnRule(int minChunks, int maxChunks, String poolName) {
        this.minChunks = minChunks;
        this.maxChunks = maxChunks;
        this.poolName  = poolName;
    }
}

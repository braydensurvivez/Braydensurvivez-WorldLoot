package com.braydensurvivez.worldloot.entity;

import com.braydensurvivez.worldloot.WorldLootMod;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Loads EntitySpawnPool objects from JSON files found in:
 *   config/worldloot/entitypools/<name>.json
 *
 * Also bundles a default "zombies" pool from resources so there is always
 * at least one pool to work with on a fresh install.
 */
public class EntitySpawnPoolRegistry {

    private final Map<String, EntitySpawnPool> pools = new LinkedHashMap<>();

    public EntitySpawnPoolRegistry() { }

    /** Reload all entity pools from disk. Call on server start and /reload. */
    public void reload(Path configDir) {
        pools.clear();

        Path poolDir = configDir.resolve("worldloot").resolve("entitypools");

        // Write default pools on first run
        writeDefaults(poolDir);

        if (!Files.isDirectory(poolDir)) {
            WorldLootMod.LOGGER.warn("[WorldLoot/EntityPool] Entity pool directory not found: {}", poolDir);
            return;
        }

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(poolDir, "*.json")) {
            for (Path file : stream) {
                String poolName = file.getFileName().toString().replace(".json", "");
                try (Reader r = new InputStreamReader(Files.newInputStream(file), StandardCharsets.UTF_8)) {
                    EntitySpawnPool pool = parse(poolName, r);
                    pools.put(poolName, pool);
                    WorldLootMod.LOGGER.info("[WorldLoot/EntityPool] Loaded pool '{}' ({} entries).", poolName, pool.size());
                } catch (Exception e) {
                    WorldLootMod.LOGGER.error("[WorldLoot/EntityPool] Failed to load pool '{}': {}", poolName, e.getMessage());
                }
            }
        } catch (IOException e) {
            WorldLootMod.LOGGER.error("[WorldLoot/EntityPool] Error reading entity pool directory: {}", e.getMessage());
        }
    }

    private EntitySpawnPool parse(String poolName, Reader reader) {
        EntitySpawnPool pool = new EntitySpawnPool(poolName);
        JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
        JsonArray entries = root.getAsJsonArray("entries");
        for (JsonElement el : entries) {
            JsonObject obj = el.getAsJsonObject();
            String entity = obj.get("entity").getAsString();
            int weight    = obj.get("weight").getAsInt();
            pool.addEntry(entity, weight);
        }
        return pool;
    }

    /** Copy default JSON pools from the mod jar into config/worldloot/entitypools/ if missing. */
    private void writeDefaults(Path poolDir) {
        try {
            Files.createDirectories(poolDir);
        } catch (IOException e) {
            WorldLootMod.LOGGER.warn("[WorldLoot/EntityPool] Could not create entity pool directory: {}", e.getMessage());
            return;
        }

        String[] defaults = { "zombies", "hostile_mix", "passive_animals", "vehicles" };
        for (String name : defaults) {
            Path target = poolDir.resolve(name + ".json");
            if (Files.exists(target)) continue;
            String resource = "/defaultentitypools/" + name + ".json";
            try (InputStream in = EntitySpawnPoolRegistry.class.getResourceAsStream(resource)) {
                if (in == null) {
                    WorldLootMod.LOGGER.warn("[WorldLoot/EntityPool] Default pool resource '{}' not found in jar.", resource);
                    continue;
                }
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
                WorldLootMod.LOGGER.info("[WorldLoot/EntityPool] Wrote default entity pool: {}", target);
            } catch (IOException e) {
                WorldLootMod.LOGGER.warn("[WorldLoot/EntityPool] Could not write default entity pool '{}': {}", name, e.getMessage());
            }
        }
    }

    /** Returns named pool or null. */
    public EntitySpawnPool getPool(String name) {
        return pools.get(name);
    }

    /** All registered pool names. */
    public Set<String> getPoolNames() {
        return Collections.unmodifiableSet(pools.keySet());
    }
}

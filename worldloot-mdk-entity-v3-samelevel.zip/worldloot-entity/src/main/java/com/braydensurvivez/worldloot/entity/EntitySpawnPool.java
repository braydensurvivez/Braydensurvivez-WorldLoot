package com.braydensurvivez.worldloot.entity;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Weighted pool of entity types loaded from a JSON spawn-pool file.
 *
 * JSON format (entitypools/<name>.json):
 * {
 *   "description": "optional human-readable text",
 *   "entries": [
 *     { "entity": "minecraft:zombie",   "weight": 60 },
 *     { "entity": "minecraft:skeleton", "weight": 30 },
 *     { "entity": "minecraft:creeper",  "weight": 10 }
 *   ]
 * }
 *
 * Higher weight = more common. Rarity label is derived from the weight
 * relative to the pool's total weight:
 *   >= 50% → Common
 *   >= 25% → Uncommon
 *   >= 10% → Rare
 *   >= 3%  → Very Rare
 *            → Legendary
 */
public class EntitySpawnPool {

    private final String poolName;
    private final List<EntitySpawnEntry> entries = new ArrayList<>();
    private int totalWeight  = 0;
    private int invalidCount = 0;

    public EntitySpawnPool(String poolName) {
        this.poolName = poolName;
    }

    /** Called during JSON parsing to add a validated entry. */
    public void addEntry(String entityIdStr, int weight) {
        if (weight <= 0) {
            WorldLootMod.LOGGER.warn("[WorldLoot/EntityPool] Pool '{}': weight must be > 0 for '{}' – skipping.", poolName, entityIdStr);
            invalidCount++;
            return;
        }

        ResourceLocation rl = ResourceLocation.tryParse(entityIdStr);
        if (rl == null) {
            WorldLootMod.LOGGER.warn("[WorldLoot/EntityPool] Pool '{}': invalid resource location '{}' – skipping.", poolName, entityIdStr);
            invalidCount++;
            return;
        }

        if (!ForgeRegistries.ENTITY_TYPES.containsKey(rl)) {
            WorldLootMod.LOGGER.warn("[WorldLoot/EntityPool] Pool '{}': unknown entity type '{}' – skipping.", poolName, entityIdStr);
            invalidCount++;
            return;
        }

        entries.add(new EntitySpawnEntry(rl, weight));
        totalWeight += weight;
    }

    /** Weighted-random pick. Returns null if pool is empty. */
    public EntitySpawnEntry pick(Random rng) {
        if (entries.isEmpty()) return null;
        int roll = rng.nextInt(totalWeight);
        int cumulative = 0;
        for (EntitySpawnEntry e : entries) {
            cumulative += e.weight;
            if (roll < cumulative) return e;
        }
        return entries.get(entries.size() - 1);
    }

    /**
     * Human-readable rarity label for a given entry, based on its share of
     * the pool's total weight.
     */
    public String rarityLabel(EntitySpawnEntry entry) {
        if (totalWeight == 0) return "Unknown";
        double pct = (double) entry.weight / totalWeight * 100.0;
        if (pct >= 50.0) return "Common";
        if (pct >= 25.0) return "Uncommon";
        if (pct >= 10.0) return "Rare";
        if (pct >= 3.0)  return "Very Rare";
        return "Legendary";
    }

    /** Percentage chance (0–100) for a given entry. */
    public double chancePercent(EntitySpawnEntry entry) {
        if (totalWeight == 0) return 0;
        return (double) entry.weight / totalWeight * 100.0;
    }

    public boolean isEmpty()                         { return entries.isEmpty(); }
    public int size()                                { return entries.size(); }
    public int getInvalidCount()                     { return invalidCount; }
    public String getName()                          { return poolName; }
    public int getTotalWeight()                      { return totalWeight; }
    public List<EntitySpawnEntry> getEntries()       { return Collections.unmodifiableList(entries); }
}

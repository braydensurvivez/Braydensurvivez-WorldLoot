package com.braydensurvivez.worldloot.entity;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.List;

/**
 * Evaluates global entity spawn rules on a fixed server-tick interval.
 *
 * Every SPAWN_INTERVAL ticks (5 seconds / 100 ticks), the handler:
 *   1. Counts loaded chunks across all dimensions.
 *   2. For each rule whose [minChunks, maxChunks] window matches the current
 *      loaded-chunk count, spawns one entity from that rule's pool.
 *      The rule continues to fire every interval indefinitely for as long as
 *      the chunk-count condition remains satisfied — it is not a one-shot.
 *   3. If debug mode is ON (per EntitySpawnDebugData):
 *        • The spawned mob receives the Glowing status effect so operators
 *          can see it through walls.
 *        • A rich spawn report is broadcast to all online operators in chat.
 *
 * Semantics of min / max:
 *   These are NOT chunk distances from a player.  They are the minimum and
 *   maximum total number of loaded chunks (across all dimensions) required
 *   for the rule to fire.  For example, a rule with min=1 max=5 fires any
 *   time between 1 and 5 chunks are loaded server-wide.
 *
 *   The actual spawn position is always placed 3–6 chunks away from a
 *   randomly chosen online player (handled by EntitySpawnEngine).
 */
public class EntitySpawnTickHandler {

    /**
     * Fixed tick interval between spawn evaluations.
     * 100 ticks = 5 seconds at 20 TPS.
     */
    private static final int SPAWN_INTERVAL = 100;

    private int tickCounter = 0;

    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        tickCounter++;
        if (tickCounter < SPAWN_INTERVAL) return;
        tickCounter = 0;

        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        ServerLevel overworld = server.overworld();
        EntitySpawnRuleData ruleData  = EntitySpawnRuleData.get(overworld);
        List<EntitySpawnRule> rules   = ruleData.getRules();
        if (rules.isEmpty()) return;

        int loadedChunks = countLoadedChunks(server);
        boolean debugOn  = EntitySpawnDebugData.get(overworld).isDebugEnabled();
        EntitySpawnPoolRegistry registry = WorldLootMod.getEntitySpawnPoolRegistry();

        for (EntitySpawnRule rule : rules) {
            // ── Chunk-count gate ───────────────────────────────────────────────
            // min/max are the loaded-chunk quota thresholds, NOT spawn distances.
            // The rule fires on every interval tick where this condition is true.
            if (loadedChunks < rule.minChunks || loadedChunks > rule.maxChunks) {
                if (debugOn) {
                    WorldLootMod.LOGGER.info(
                            "[WorldLoot/EntitySpawn][DEBUG] Rule [{}-{} chunks, pool='{}'] SKIPPED — " +
                            "loaded chunks: {}.",
                            rule.minChunks, rule.maxChunks, rule.poolName, loadedChunks);
                }
                continue;
            }

            // ── Spawn one entity from the pool ─────────────────────────────────
            // Pass debugOn so the engine can apply the Glowing effect immediately
            // after the entity is added to the world.
            EntitySpawnEngine.SpawnResult result =
                    EntitySpawnEngine.spawnFromPool(overworld, registry, rule.poolName, debugOn);

            if (result.success) {
                WorldLootMod.LOGGER.info(
                        "[WorldLoot/EntitySpawn] Spawned '{}' ({}) at {} from pool '{}'. " +
                        "Loaded chunks: {}. Offset: {} chunks from {}." +
                        (debugOn ? " [DEBUG: Glowing applied]" : ""),
                        result.entityId,
                        result.pool.rarityLabel(result.entry),
                        result.spawnPos,
                        rule.poolName,
                        loadedChunks,
                        result.chunkDistance,
                        result.nearestPlayer.getName().getString());

                if (debugOn) {
                    broadcastDebug(server, buildDebugMessage(result, rule, loadedChunks));
                }

            } else {
                WorldLootMod.LOGGER.warn(
                        "[WorldLoot/EntitySpawn] Spawn attempt FAILED for pool '{}': {}",
                        rule.poolName, result.failReason);

                if (debugOn) {
                    broadcastDebug(server,
                            "§c[WL/Entity DEBUG] FAILED pool='" + rule.poolName +
                            "' reason=" + result.failReason);
                }
            }
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private static int countLoadedChunks(MinecraftServer server) {
        int total = 0;
        for (ServerLevel level : server.getAllLevels()) {
            total += level.getChunkSource().getLoadedChunksCount();
        }
        return total;
    }

    /**
     * Build the rich debug chat message shown to ops on each spawn.
     *
     * Format:
     *   [WL/Entity DEBUG] ─────────────────────────────
     *   Entity  : minecraft:zombie  (Common  48.3%)  ✦ Glowing
     *   Pool    : zombies
     *   Position: x=142 y=64 z=-308  (chunk 8, -20)
     *   Offset  : 4 chunks from Steve
     *   Chunks  : 87 loaded  [rule: 50–200]
     *   ────────────────────────────────────────────────
     */
    private static String buildDebugMessage(EntitySpawnEngine.SpawnResult result,
                                            EntitySpawnRule rule,
                                            int loadedChunks) {
        String divider = "§8─────────────────────────────────";
        int cx = result.spawnPos.getX() >> 4;
        int cz = result.spawnPos.getZ() >> 4;
        double pct = result.pool.chancePercent(result.entry);

        return divider + "\n" +
               "§e[WL/Entity DEBUG]\n" +
               "§7Entity  : §f" + result.entityId +
                   "  §7(§b" + result.pool.rarityLabel(result.entry) +
                   " §7" + String.format("%.1f", pct) + "%§7)" +
                   "  §a✦ Glowing\n" +
               "§7Pool    : §f" + rule.poolName + "\n" +
               "§7Position: §f" + result.spawnPos.getX() + " " +
                   result.spawnPos.getY() + " " + result.spawnPos.getZ() +
                   "  §8(chunk " + cx + ", " + cz + ")\n" +
               "§7Offset  : §f" + result.chunkDistance + " chunks §7from §f" +
                   result.nearestPlayer.getName().getString() + "\n" +
               "§7Chunks  : §f" + loadedChunks + " §7loaded  §8[rule: " +
                   rule.minChunks + "–" + rule.maxChunks + "]\n" +
               divider;
    }

    private static void broadcastDebug(MinecraftServer server, String text) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (server.getPlayerList().isOp(p.getGameProfile())) {
                p.sendSystemMessage(Component.literal(text));
            }
        }
    }
}

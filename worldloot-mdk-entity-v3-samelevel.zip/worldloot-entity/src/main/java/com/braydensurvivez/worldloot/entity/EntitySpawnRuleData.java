package com.braydensurvivez.worldloot.entity;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Persists the list of global entity spawn rules created by:
 *   /braydensurvivezworldloot deploy global <min> <max> <pool>
 *
 * Stored in world/data/worldloot_entity_rules.dat
 */
public class EntitySpawnRuleData extends SavedData {

    private static final String DATA_NAME = WorldLootMod.MOD_ID + "_entity_rules";

    private final List<EntitySpawnRule> rules = new ArrayList<>();

    // ── Factory ────────────────────────────────────────────────────────────────

    public static EntitySpawnRuleData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(
                EntitySpawnRuleData::load,
                EntitySpawnRuleData::new,
                DATA_NAME
        );
    }

    public EntitySpawnRuleData() { }

    private static EntitySpawnRuleData load(CompoundTag tag) {
        EntitySpawnRuleData data = new EntitySpawnRuleData();
        ListTag list = tag.getList("rules", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            int    min  = entry.getInt("min");
            int    max  = entry.getInt("max");
            String pool = entry.getString("pool");
            data.rules.add(new EntitySpawnRule(min, max, pool));
        }
        return data;
    }

    // ── Save ───────────────────────────────────────────────────────────────────

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (EntitySpawnRule r : rules) {
            CompoundTag entry = new CompoundTag();
            entry.putInt("min",    r.minChunks);
            entry.putInt("max",    r.maxChunks);
            entry.putString("pool", r.poolName);
            list.add(entry);
        }
        tag.put("rules", list);
        return tag;
    }

    // ── API ────────────────────────────────────────────────────────────────────

    public void addRule(EntitySpawnRule rule) {
        rules.add(rule);
        setDirty();
    }

    /**
     * Remove the first rule that matches min, max, and pool exactly.
     * Returns true if a rule was removed.
     */
    public boolean removeRule(int min, int max, String pool) {
        boolean removed = rules.removeIf(r ->
                r.minChunks == min && r.maxChunks == max && r.poolName.equalsIgnoreCase(pool));
        if (removed) setDirty();
        return removed;
    }

    public void clearAll() {
        rules.clear();
        setDirty();
    }

    public List<EntitySpawnRule> getRules() {
        return Collections.unmodifiableList(rules);
    }
}

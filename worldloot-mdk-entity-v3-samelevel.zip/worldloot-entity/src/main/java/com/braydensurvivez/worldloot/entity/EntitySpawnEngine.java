package com.braydensurvivez.worldloot.entity;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Picks a random entity from a named EntitySpawnPool and spawns it in the world
 * at a position some chunks away from a randomly selected online player.
 *
 * The min/max values in EntitySpawnRule are NOT distances — they are the
 * minimum and maximum total loaded chunk counts required for a spawn rule to
 * fire. Once that chunk-count quota is reached the tick handler calls this
 * engine, which then places the entity 3–6 chunks away from a random player.
 *
 * Returns a SpawnResult describing what happened (used by the debug system
 * and by manual /entity spawn command feedback).
 */
public class EntitySpawnEngine {

    /**
     * How far away (in chunk units) to place the spawned entity from the
     * triggering player.  These are fixed offsets independent of the
     * rule's min/max chunk count window.
     */
    private static final int SPAWN_CHUNK_OFFSET_MIN = 3;
    private static final int SPAWN_CHUNK_OFFSET_MAX = 6;

    /**
     * Duration of the Glowing effect applied to debug-mode spawns, in ticks.
     * 6000 ticks = 5 minutes.
     */
    private static final int DEBUG_GLOW_DURATION_TICKS = 6000;

    private static final Random RNG = new Random();

    // ── Result record ──────────────────────────────────────────────────────────

    public static class SpawnResult {
        public final boolean success;
        /** Entity that was spawned, or null on failure. */
        public final Entity  entity;
        /** ResourceLocation of the entity type picked. */
        public final ResourceLocation entityId;
        /** Pool entry that was selected. */
        public final EntitySpawnEntry entry;
        /** Pool the entry came from. */
        public final EntitySpawnPool  pool;
        /** World position of the spawn. */
        public final BlockPos         spawnPos;
        /** Player the spawn was offset from. */
        public final ServerPlayer     nearestPlayer;
        /** Chunk distance from the player (in chunk units). */
        public final int              chunkDistance;
        /** Human-readable failure reason, or null on success. */
        public final String           failReason;

        private SpawnResult(boolean success, Entity entity, ResourceLocation entityId,
                            EntitySpawnEntry entry, EntitySpawnPool pool,
                            BlockPos spawnPos, ServerPlayer nearestPlayer,
                            int chunkDistance, String failReason) {
            this.success       = success;
            this.entity        = entity;
            this.entityId      = entityId;
            this.entry         = entry;
            this.pool          = pool;
            this.spawnPos      = spawnPos;
            this.nearestPlayer = nearestPlayer;
            this.chunkDistance = chunkDistance;
            this.failReason    = failReason;
        }

        public static SpawnResult fail(String reason) {
            return new SpawnResult(false, null, null, null, null, null, null, 0, reason);
        }

        public static SpawnResult ok(Entity entity, ResourceLocation entityId,
                                     EntitySpawnEntry entry, EntitySpawnPool pool,
                                     BlockPos pos, ServerPlayer player, int chunkDist) {
            return new SpawnResult(true, entity, entityId, entry, pool, pos, player, chunkDist, null);
        }
    }

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Attempt to spawn one entity from poolName in level.
     * If debugMode is true, the Glowing effect is applied to the spawned mob
     * so operators can visually track it in-world.
     * Returns a SpawnResult regardless of success.
     */
    public static SpawnResult spawnFromPool(ServerLevel level,
                                            EntitySpawnPoolRegistry registry,
                                            String poolName,
                                            boolean debugMode) {
        EntitySpawnPool pool = registry.getPool(poolName);
        if (pool == null || pool.isEmpty()) {
            return SpawnResult.fail("Pool '" + poolName + "' is null or empty");
        }

        List<ServerPlayer> players = level.getServer().getPlayerList().getPlayers();
        if (players.isEmpty()) {
            return SpawnResult.fail("No players online");
        }
        ServerPlayer target = players.get(RNG.nextInt(players.size()));

        // Weighted-random pick from pool
        EntitySpawnEntry entry = pool.pick(RNG);
        if (entry == null) {
            return SpawnResult.fail("Pool pick returned null (pool may be empty)");
        }

        EntityType<?> entityType = ForgeRegistries.ENTITY_TYPES.getValue(entry.entityId);
        if (entityType == null) {
            return SpawnResult.fail("Entity type '" + entry.entityId + "' not found in registry");
        }

        // Find a valid spawn position near the player in a loaded chunk
        int[] chunkDistHolder = {0};
        Optional<BlockPos> posOpt = findOffsetSpawnPos(level, target, chunkDistHolder);
        if (posOpt.isEmpty()) {
            return SpawnResult.fail("No valid spawn position found near "
                    + target.getName().getString() + " after 32 attempts");
        }

        BlockPos pos = posOpt.get();
        Entity entity = entityType.create(level);
        if (entity == null) {
            return SpawnResult.fail("EntityType.create() returned null for '" + entry.entityId + "'");
        }

        entity.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);

        if (entity instanceof Mob mob) {
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null, null);
        }

        boolean added = level.addFreshEntity(entity);
        if (!added) {
            return SpawnResult.fail("addFreshEntity() returned false for '" + entry.entityId + "' at " + pos);
        }

        // ── Debug: apply Glowing effect ───────────────────────────────────────
        // When debug mode is active, give every spawned LivingEntity the
        // Glowing status effect so ops can see it through walls.
        if (debugMode && entity instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(
                    MobEffects.GLOWING,
                    DEBUG_GLOW_DURATION_TICKS,
                    0,          // amplifier (level 1)
                    false,      // ambient
                    true,       // show particles
                    true        // show icon
            ));
        }

        return SpawnResult.ok(entity, entry.entityId, entry, pool, pos, target, chunkDistHolder[0]);
    }

    /**
     * Legacy overload without debugMode — defaults to no glow.
     * Used by the manual /entity spawn command when debug is not checked upstream.
     */
    public static SpawnResult spawnFromPool(ServerLevel level,
                                            EntitySpawnPoolRegistry registry,
                                            String poolName) {
        return spawnFromPool(level, registry, poolName, false);
    }

    // ── Position finding ───────────────────────────────────────────────────────

    /**
     * How many blocks above and below the player's Y level to search for a
     * valid ground position.  Keeping this tight prevents spawning on roofs
     * or in underground caves that happen to be at a very different elevation.
     */
    private static final int VERTICAL_SEARCH_RANGE = 16;

    /**
     * Finds a valid ground-level position SPAWN_CHUNK_OFFSET_MIN – SPAWN_CHUNK_OFFSET_MAX
     * chunks from the player, at approximately the same Y level as the player.
     *
     * KEY FIX (original): The previous implementation rejected any chunk that was not
     * already loaded (level.hasChunk() == false).  In practice this caused
     * almost every attempt to fail, because chunks a few steps away from the
     * player are often not yet in the server's loaded-chunk set even though
     * they will be imminently loaded.
     *
     * SAME-LEVEL FIX: Instead of using MOTION_BLOCKING_NO_LEAVES (which returns
     * the absolute highest block — roof, treetop, etc.) we now search for a
     * solid-ground + two-air-block gap near the player's own Y coordinate.
     * This prevents entities from spawning on rooftops or elevated structures
     * that are above the player's current floor.
     *
     * The corrected approach:
     *   1. Pick a random angle and chunk distance.
     *   2. Load or force-access the target chunk.
     *   3. Starting at the player's Y, scan downward (then upward) within
     *      VERTICAL_SEARCH_RANGE blocks to find: solid block below, air at
     *      foot level, air at head level.
     *   4. Only accept positions within that vertical window — reject anything
     *      that would place the mob on a roof or deep underground.
     *
     * Writes the chosen chunk distance into chunkDistHolder[0].
     */
    private static Optional<BlockPos> findOffsetSpawnPos(ServerLevel level,
                                                          ServerPlayer player,
                                                          int[] chunkDistHolder) {
        Vec3 playerPos   = player.position();
        int playerChunkX = (int) playerPos.x >> 4;
        int playerChunkZ = (int) playerPos.z >> 4;
        int playerY      = (int) Math.floor(playerPos.y);

        for (int attempt = 0; attempt < 32; attempt++) {
            double angle         = RNG.nextDouble() * 2 * Math.PI;
            int    chunkDistance = SPAWN_CHUNK_OFFSET_MIN
                    + RNG.nextInt(SPAWN_CHUNK_OFFSET_MAX - SPAWN_CHUNK_OFFSET_MIN + 1);

            int targetChunkX = playerChunkX + (int) Math.round(Math.cos(angle) * chunkDistance);
            int targetChunkZ = playerChunkZ + (int) Math.round(Math.sin(angle) * chunkDistance);

            // Force the chunk to be accessible for heightmap sampling.
            // getChunk() with FULL status will load/generate it if necessary.
            // We do NOT skip unloaded chunks — that was the original bug.
            net.minecraft.world.level.chunk.LevelChunk chunk;
            try {
                chunk = level.getChunk(targetChunkX, targetChunkZ);
            } catch (Exception e) {
                // Chunk generation threw unexpectedly — rare, skip this attempt
                WorldLootMod.LOGGER.debug(
                        "[WorldLoot/EntitySpawn] Chunk ({},{}) threw during access: {}",
                        targetChunkX, targetChunkZ, e.getMessage());
                continue;
            }

            if (chunk == null) continue;

            int blockX = (targetChunkX << 4) + RNG.nextInt(16);
            int blockZ = (targetChunkZ << 4) + RNG.nextInt(16);

            // Search downward from the player's Y within VERTICAL_SEARCH_RANGE.
            // This keeps spawns on the same "floor" as the player rather than
            // on rooftops or the absolute surface heightmap.
            BlockPos groundPos = findGroundNearY(level, blockX, blockZ, playerY);
            if (groundPos == null) continue;

            chunkDistHolder[0] = chunkDistance;
            return Optional.of(groundPos);
        }

        return Optional.empty();
    }

    /**
     * Scans from (blockX, startY, blockZ) downward (then upward) within
     * VERTICAL_SEARCH_RANGE blocks to find a position where:
     *   - the block below is solid
     *   - the block at foot level is air
     *   - the block at head level is air
     *
     * Returns the foot-level BlockPos on success, or null if no valid
     * position exists in the search window.
     */
    private static BlockPos findGroundNearY(ServerLevel level, int blockX, int blockZ, int startY) {
        int minY = startY - VERTICAL_SEARCH_RANGE;
        int maxY = startY + VERTICAL_SEARCH_RANGE;

        // Clamp to world bounds
        int worldMinY = level.getMinBuildHeight() + 1;
        int worldMaxY = level.getMaxBuildHeight() - 2;
        minY = Math.max(minY, worldMinY);
        maxY = Math.min(maxY, worldMaxY);

        // Scan downward from startY first (ground is typically below the player).
        for (int y = startY; y >= minY; y--) {
            BlockPos candidate = new BlockPos(blockX, y, blockZ);
            if (isValidSpawnPos(level, candidate)) return candidate;
        }

        // If nothing was found below, try upward (e.g., player is in a trench).
        for (int y = startY + 1; y <= maxY; y++) {
            BlockPos candidate = new BlockPos(blockX, y, blockZ);
            if (isValidSpawnPos(level, candidate)) return candidate;
        }

        return null;
    }

    /**
     * Returns true when pos is a valid two-block-tall spawn slot:
     *   solid block at pos.below(), air at pos (feet), air at pos.above() (head).
     */
    private static boolean isValidSpawnPos(ServerLevel level, BlockPos pos) {
        BlockState ground = level.getBlockState(pos.below());
        BlockState air1   = level.getBlockState(pos);
        BlockState air2   = level.getBlockState(pos.above());
        return ground.isSolid() && air1.isAir() && air2.isAir();
    }
}

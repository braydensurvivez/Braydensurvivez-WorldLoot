package com.braydensurvivez.worldloot;

import com.braydensurvivez.worldloot.command.WorldLootCommand;
import com.braydensurvivez.worldloot.config.WorldLootConfig;
import com.braydensurvivez.worldloot.entity.EntitySpawnPoolRegistry;
import com.braydensurvivez.worldloot.entity.EntitySpawnTickHandler;
import com.braydensurvivez.worldloot.loot.ContainerInteractHandler;
import com.braydensurvivez.worldloot.loot.LootPoolRegistry;
import com.braydensurvivez.worldloot.data.TurnBackTimeData;
import com.braydensurvivez.worldloot.loot.TurnBackTimeEngine;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(WorldLootMod.MOD_ID)
public class WorldLootMod {

    public static final String MOD_ID = "worldloot";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    /**
     * Shared loot pool registry — loaded once on server start and on /reload.
     * ContainerInteractHandler and DeployEngine both read from this instance.
     */
    private static final LootPoolRegistry POOL_REGISTRY = new LootPoolRegistry();

    /**
     * Shared entity spawn pool registry — loaded once on server start and on /reload.
     * EntitySpawnEngine reads from this instance.
     */
    private static final EntitySpawnPoolRegistry ENTITY_SPAWN_POOL_REGISTRY = new EntitySpawnPoolRegistry();

    private final EntitySpawnTickHandler entitySpawnTickHandler = new EntitySpawnTickHandler();

    public static LootPoolRegistry getPoolRegistry() {
        return POOL_REGISTRY;
    }

    public static EntitySpawnPoolRegistry getEntitySpawnPoolRegistry() {
        return ENTITY_SPAWN_POOL_REGISTRY;
    }

    public WorldLootMod(FMLJavaModLoadingContext context) {

        context.registerConfig(ModConfig.Type.SERVER, WorldLootConfig.SERVER_SPEC, "worldloot-server.toml");

        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);
        MinecraftForge.EVENT_BUS.addListener(this::onServerStarted);
        MinecraftForge.EVENT_BUS.addListener(this::onConfigReload);
        MinecraftForge.EVENT_BUS.addListener(this::onRightClickBlock);
        MinecraftForge.EVENT_BUS.addListener(this::onBlockPlace);
        MinecraftForge.EVENT_BUS.addListener(this::onServerTick);

        LOGGER.info("[WorldLoot] Mod initialised.");
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        WorldLootCommand.register(event.getDispatcher());
        LOGGER.info("[WorldLoot] Commands registered.");
    }

    private void onServerStarted(ServerStartedEvent event) {
        POOL_REGISTRY.reload();
        LOGGER.info("[WorldLoot] Loot pools loaded: {}", POOL_REGISTRY.getPoolNames());

        ENTITY_SPAWN_POOL_REGISTRY.reload(FMLPaths.CONFIGDIR.get());
        LOGGER.info("[WorldLoot] Entity spawn pools loaded: {}", ENTITY_SPAWN_POOL_REGISTRY.getPoolNames());
    }

    private void onConfigReload(net.minecraftforge.fml.event.config.ModConfigEvent.Reloading event) {
        if (event.getConfig().getModId().equals(MOD_ID)) {
            POOL_REGISTRY.reload();
            LOGGER.info("[WorldLoot] Config reloaded — loot pools refreshed: {}", POOL_REGISTRY.getPoolNames());

            ENTITY_SPAWN_POOL_REGISTRY.reload(FMLPaths.CONFIGDIR.get());
            LOGGER.info("[WorldLoot] Config reloaded — entity spawn pools refreshed: {}", ENTITY_SPAWN_POOL_REGISTRY.getPoolNames());
        }
    }

    private void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        ContainerInteractHandler.onRightClickBlock(event);
    }

    private void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        ContainerInteractHandler.onBlockPlace(event);
    }

    /** How many server ticks between global TurnBackTime sweeps (200 = 10 seconds). */
    private static final int SWEEP_INTERVAL = 200;
    private int turnBackTickCounter = 0;

    private void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        // TurnBackTime global sweeper
        turnBackTickCounter++;
        if (turnBackTickCounter >= SWEEP_INTERVAL) {
            turnBackTickCounter = 0;
            net.minecraft.server.MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
            if (server != null) {
                TurnBackTimeData data = TurnBackTimeData.get(server.overworld());
                if (data.isGlobalEnabled()) {
                    TurnBackTimeEngine.clearAllLoaded(server);
                }
            }
        }

        // Entity spawn tick handler
        entitySpawnTickHandler.onServerTick(event);
    }
}

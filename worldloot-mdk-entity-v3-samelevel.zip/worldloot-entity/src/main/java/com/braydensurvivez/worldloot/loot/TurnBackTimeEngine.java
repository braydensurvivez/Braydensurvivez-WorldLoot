package com.braydensurvivez.worldloot.loot;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;

import java.util.ArrayList;
import java.util.List;

/**
 * Scans loaded chunks across all server dimensions and removes blocks that
 * were player-placed and are vines or leaves.
 *
 * Minecraft marks player-placed blocks by clearing the PERSISTENT flag on
 * leaf blocks.  For 1.20.1 Forge, however, the most reliable signal is the
 * LevelChunk block-entity / block-event system: player-placed leaves have
 * their distance set to 7 (max) and will NOT decay naturally (persistent=true).
 *
 * Detection strategy used here:
 *   • Leaves  – we remove ALL leaf blocks whose "persistent" state is TRUE.
 *               Natural leaves placed by world-gen set persistent=false so
 *               they eventually decay; player-placed ones set persistent=true.
 *   • Vines   – there is no native "player placed" flag, so we remove ALL
 *               vine blocks found.  (Natural vine growth re-attaches anyway.)
 *
 * The caller decides the area to scan (one-shot radius vs all loaded chunks).
 */
public class TurnBackTimeEngine {

    /** Block tags / block references for the blocks we clear. */
    private static boolean isTargetBlock(BlockState state) {
        Block block = state.getBlock();

        // Vines - always remove
        if (block == Blocks.VINE) return true;

        // Cave vines (both parts)
        if (block == Blocks.CAVE_VINES || block == Blocks.CAVE_VINES_PLANT) return true;

        // Twisting / weeping nether vines
        if (block == Blocks.TWISTING_VINES || block == Blocks.TWISTING_VINES_PLANT) return true;
        if (block == Blocks.WEEPING_VINES  || block == Blocks.WEEPING_VINES_PLANT)  return true;

        // Glow lichen (often used decoratively like vines)
        if (block == Blocks.GLOW_LICHEN) return true;

        // Leaf blocks - only remove player-placed ones (persistent = true)
        if (state.hasProperty(net.minecraft.world.level.block.LeavesBlock.PERSISTENT)) {
            return state.getValue(net.minecraft.world.level.block.LeavesBlock.PERSISTENT);
        }

        return false;
    }

    // ── Result record ──────────────────────────────────────────────────────────

    public static class ClearResult {
        public int chunksScanned = 0;
        public int blocksRemoved = 0;
        public int dimensionsScanned = 0;
    }

    // ── One-shot: clear within radius of a position in one level ──────────────

    /**
     * Clears player-placed vines/leaves within {@code radius} blocks of
     * {@code center} in the given level.
     */
    public static ClearResult clearRadius(ServerLevel level, BlockPos center, int radius) {
        ClearResult result = new ClearResult();
        result.dimensionsScanned = 1;

        int minX = center.getX() - radius;
        int maxX = center.getX() + radius;
        int minY = Math.max(level.getMinBuildHeight(), center.getY() - radius);
        int maxY = Math.min(level.getMaxBuildHeight() - 1, center.getY() + radius);
        int minZ = center.getZ() - radius;
        int maxZ = center.getZ() + radius;

        // Collect positions first to avoid CME
        List<BlockPos> toRemove = new ArrayList<>();
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                // Only iterate loaded chunks
                int chunkX = x >> 4;
                int chunkZ = z >> 4;
                if (!level.hasChunk(chunkX, chunkZ)) continue;
                for (int y = minY; y <= maxY; y++) {
                    mutable.set(x, y, z);
                    BlockState state = level.getBlockState(mutable);
                    if (isTargetBlock(state)) {
                        toRemove.add(mutable.immutable());
                    }
                }
            }
        }

        for (BlockPos pos : toRemove) {
            level.removeBlock(pos, false);
            result.blocksRemoved++;
        }

        // Rough chunk count
        result.chunksScanned = toRemove.isEmpty() ? 0 : 1;
        WorldLootMod.LOGGER.info("[WorldLoot/TurnBackTime] Radius clear: removed {} blocks.", result.blocksRemoved);
        return result;
    }

    // ── Global sweep: all loaded chunks in all dimensions ─────────────────────

    /**
     * Sweeps every loaded chunk in every server dimension and removes
     * player-placed vines/leaves.
     *
     * Uses reflection to access the protected ChunkMap#getChunks() in
     * Forge 1.20.1, falling back gracefully if unavailable.
     */
    public static ClearResult clearAllLoaded(MinecraftServer server) {
        ClearResult result = new ClearResult();

        for (ServerLevel level : server.getAllLevels()) {
            result.dimensionsScanned++;
            List<BlockPos> toRemove = new ArrayList<>();

            // Collect loaded chunk positions via reflection on ChunkMap#getChunks()
            // getChunks() is protected in ChunkMap, so we must bypass access control.
            List<ChunkPos> loadedChunkPositions = getLoadedChunkPositions(level);

            for (ChunkPos cp : loadedChunkPositions) {
                LevelChunk lc = level.getChunkSource().getChunkNow(cp.x, cp.z);
                if (lc == null) continue;
                result.chunksScanned++;

                int baseX = cp.getMinBlockX();
                int baseZ = cp.getMinBlockZ();
                BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();
                for (int x = baseX; x < baseX + 16; x++) {
                    for (int z = baseZ; z < baseZ + 16; z++) {
                        for (int y = level.getMinBuildHeight(); y < level.getMaxBuildHeight(); y++) {
                            mutable.set(x, y, z);
                            BlockState state = level.getBlockState(mutable);
                            if (isTargetBlock(state)) {
                                toRemove.add(mutable.immutable());
                            }
                        }
                    }
                }
            }

            for (BlockPos pos : toRemove) {
                level.removeBlock(pos, false);
                result.blocksRemoved++;
            }
        }

        if (result.blocksRemoved > 0) {
            WorldLootMod.LOGGER.info("[WorldLoot/TurnBackTime] Global sweep: removed {} blocks across {} dims, {} chunks.",
                    result.blocksRemoved, result.dimensionsScanned, result.chunksScanned);
        }
        return result;
    }

    /**
     * Returns the positions of all currently loaded chunks in the given level.
     *
     * ChunkMap#getChunks() is protected, so we use reflection to call it.
     * The method returns an Iterable of ChunkHolder; we read getPos() from each.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static List<ChunkPos> getLoadedChunkPositions(ServerLevel level) {
        List<ChunkPos> positions = new ArrayList<>();
        try {
            ServerChunkCache chunkSource = level.getChunkSource();
            // net.minecraft.server.level.ChunkMap
            Object chunkMap = chunkSource.chunkMap;
            java.lang.reflect.Method getChunks = chunkMap.getClass()
                    .getDeclaredMethod("getChunks");
            getChunks.setAccessible(true);
            Iterable holders = (Iterable) getChunks.invoke(chunkMap);
            for (Object holder : holders) {
                // ChunkHolder#getPos() is public
                java.lang.reflect.Method getPos = holder.getClass()
                        .getMethod("getPos");
                ChunkPos pos = (ChunkPos) getPos.invoke(holder);
                positions.add(pos);
            }
        } catch (Exception e) {
            WorldLootMod.LOGGER.warn("[WorldLoot/TurnBackTime] Could not reflect ChunkMap#getChunks(): {}", e.getMessage());
        }
        return positions;
    }
}

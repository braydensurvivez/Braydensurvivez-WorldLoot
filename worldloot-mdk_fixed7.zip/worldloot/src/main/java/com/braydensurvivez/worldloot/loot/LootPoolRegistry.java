package com.braydensurvivez.worldloot.loot;

import com.braydensurvivez.worldloot.config.WorldLootConfig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Loads and holds all named loot pools from config.
 * Do NOT call reload() in the constructor — config is not loaded yet at class-init time.
 */
public class LootPoolRegistry {

    private final Map<String, LootPool> pools = new LinkedHashMap<>();

    public LootPoolRegistry() {
        // intentionally empty
    }

    /** Rebuild all pools from TOML config AND custom JSON files. Called at server start and /reload. */
    public void reload() {
        pools.clear();

        // 1. Load pools declared in worldloot-server.toml
        WorldLootConfig.SERVER.namedPools.forEach((name, configValue) ->
                pools.put(name, new LootPool(name, configValue.get())));

        // 2. Load custom pools from config/worldloot/pools/*.json
        //    JSON pools with the same name as a TOML pool will override it.
        java.nio.file.Path configDir = net.minecraftforge.fml.loading.FMLPaths.CONFIGDIR.get();
        java.util.Map<String, java.util.List<String>> customPools =
                com.braydensurvivez.worldloot.config.CustomPoolLoader.loadAll(configDir);
        customPools.forEach((name, entries) ->
                pools.put(name, new LootPool(name, entries)));
    }

    /**
     * Returns the named pool, or null if it doesn't exist or is empty.
     */
    public LootPool getPool(String name) {
        return pools.get(name);
    }

    /** All registered pool names (in config declaration order). */
    public Set<String> getPoolNames() {
        return Collections.unmodifiableSet(pools.keySet());
    }

    /**
     * Pick a random LootEntry from ALL pools combined.
     * Uniform pool selection, then weighted pick within the chosen pool.
     * Returns null if all pools are empty.
     */
    public LootEntry pickAny(Random rng) {
        List<LootPool> nonEmpty = new ArrayList<>();
        for (LootPool p : pools.values()) if (!p.isEmpty()) nonEmpty.add(p);
        if (nonEmpty.isEmpty()) return null;
        LootPool chosen = nonEmpty.get(rng.nextInt(nonEmpty.size()));
        return chosen.pick(rng);
    }

    /**
     * Pick from a specific named pool. Returns null if pool doesn't exist or is empty.
     */
    public LootEntry pickFromPool(String poolName, Random rng) {
        LootPool pool = pools.get(poolName);
        if (pool == null || pool.isEmpty()) return null;
        return pool.pick(rng);
    }

    public int totalInvalidEntries() {
        return pools.values().stream().mapToInt(LootPool::getInvalidEntries).sum();
    }
}

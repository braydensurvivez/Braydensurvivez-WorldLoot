package com.braydensurvivez.worldloot.loot;

import com.braydensurvivez.worldloot.WorldLootMod;
import com.braydensurvivez.worldloot.config.WorldLootConfig;
import com.braydensurvivez.worldloot.data.DeploymentTracker;
import com.braydensurvivez.worldloot.data.GlobalAssignmentData;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Triggers loot generation only when a player actually right-clicks a container.
 *
 * Anti-exploit: once the loot system is active (at least one global assignment
 * exists), any container a player PLACES is immediately stamped as "already
 * populated" in the DeploymentTracker.  That stamp is the exact same flag the
 * loot system checks before filling, so the newly placed chest is silently
 * skipped — indistinguishable from a chest that was already looted.
 *
 * /braydensurvivezloot reset clears DeploymentTracker entirely, which also
 * removes these stamps, resetting the exploit-guard along with everything else.
 */
public class ContainerInteractHandler {

    private static final Random RNG = new Random();

    /**
     * Called on PlayerInteractEvent.RightClickBlock (server side only).
     * Fires before the block's own open logic, so the container is filled
     * by the time the player's client receives the open packet.
     */
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {

        // ── Guard 1: server side only, main hand only ─────────────────────────
        if (event.getLevel().isClientSide()) return;
        if (event.getHand() != InteractionHand.MAIN_HAND) return;

        if (!(event.getLevel() instanceof ServerLevel level)) return;

        // ── Guard 2: is there a block entity at the clicked position? ─────────
        BlockPos pos = event.getPos();
        BlockEntity be = level.getBlockEntity(pos);
        if (be == null) return;

        // ── Guard 3: is it a container? ───────────────────────────────────────
        if (!(be instanceof Container inv)) return;

        // ── Guard 4: has this container already been populated (or stamped as
        //            player-placed)?  Both cases use the same tracker flag. ────
        ServerLevel overworld = level.getServer().overworld();
        DeploymentTracker tracker = DeploymentTracker.get(overworld);
        ResourceLocation dimKey = level.dimension().location();

        if (tracker.isPopulated(dimKey, pos)) return; // already done / player-placed, fast exit

        // ── Guard 5: look up a global assignment for this block type ──────────
        ResourceLocation blockId = ForgeRegistries.BLOCKS.getKey(be.getBlockState().getBlock());
        if (blockId == null) return;

        GlobalAssignmentData assignments = GlobalAssignmentData.get(overworld);
        String poolName = assignments.getPool(blockId.toString());
        if (poolName == null) return; // no assignment configured for this block type

        // ── Guard 6: respect lock / empty-only config flags ───────────────────
        if (!passesLockCheck(be)) return;
        if (WorldLootConfig.SERVER.populateEmptyOnly.get() && !isContainerEmpty(inv)) return;

        // ── Fill and mark ─────────────────────────────────────────────────────
        LootPoolRegistry reg = WorldLootMod.getPoolRegistry();
        fillContainer(inv, poolName, reg);
        tracker.markPopulated(dimKey, pos);

        WorldLootMod.LOGGER.debug(
            "[WorldLoot] Filled {} at {} in {} from pool '{}' on player interact.",
            blockId, pos, dimKey.getPath(), poolName);
    }

    // ── Anti-exploit: block-place tracking ────────────────────────────────────

    /**
     * When a player places a container block WHILE the loot system is active
     * (i.e. at least one global assignment exists), stamp that position as
     * "already populated" so loot will never spawn in it.
     *
     * This prevents the break→replace→loot exploit.  The stamp is just a normal
     * DeploymentTracker entry, so /braydensurvivezloot reset clears it for free.
     *
     * If no global assignments exist yet (system not live), we do nothing —
     * those chests pre-date the loot system and should receive loot normally.
     */
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof Player)) return;
        if (!(event.getLevel() instanceof ServerLevel level)) return;

        // Is the loot system currently active?
        ServerLevel overworld = level.getServer().overworld();
        GlobalAssignmentData assignments = GlobalAssignmentData.get(overworld);
        if (assignments.getAll().isEmpty()) return; // system not live yet, do nothing

        // Is the placed block a container type the loot system cares about?
        ResourceLocation blockId = ForgeRegistries.BLOCKS.getKey(
                event.getPlacedBlock().getBlock());
        if (blockId == null) return;
        if (!isContainerBlockId(blockId.toString().toLowerCase())) return;

        // Stamp it as already-populated so it's invisible to the loot system.
        BlockPos pos = event.getPos();
        ResourceLocation dimKey = level.dimension().location();
        DeploymentTracker.get(overworld).markPopulated(dimKey, pos);

        WorldLootMod.LOGGER.debug(
            "[WorldLoot] Player-placed container '{}' at {} in {} stamped as populated (anti-exploit).",
            blockId, pos, dimKey.getPath());
    }

    /**
     * Returns true for block IDs that represent containers the loot system targets.
     * Mirrors the DEFAULT_ALLOWED set in DeployEngine.
     */
    private static boolean isContainerBlockId(String id) {
        return id.contains("chest")
            || id.contains("barrel")
            || id.contains("shulker_box")
            || id.contains("hopper")
            || id.contains("dropper")
            || id.contains("dispenser");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static boolean isContainerEmpty(Container inv) {
        for (int i = 0; i < inv.getContainerSize(); i++)
            if (!inv.getItem(i).isEmpty()) return false;
        return true;
    }

    private static boolean passesLockCheck(BlockEntity be) {
        if (!WorldLootConfig.SERVER.ignoreLockedContainers.get()) return true;
        if (!(be instanceof BaseContainerBlockEntity base)) return true;
        try {
            java.lang.reflect.Field f = BaseContainerBlockEntity.class.getDeclaredField("lockKey");
            f.setAccessible(true);
            net.minecraft.world.LockCode lock = (net.minecraft.world.LockCode) f.get(base);
            if (lock != null) {
                net.minecraft.nbt.CompoundTag lockTag = new net.minecraft.nbt.CompoundTag();
                lock.addToTag(lockTag);
                if (!lockTag.getString("Lock").isEmpty()) return false;
            }
        } catch (Exception ignored) { }
        return true;
    }

    private static void fillContainer(Container inv, String poolName, LootPoolRegistry reg) {
        int size = inv.getContainerSize();
        if (size == 0) return;

        if (WorldLootConfig.SERVER.clearContainerBeforeFill.get()) inv.clearContent();

        int min = WorldLootConfig.SERVER.minItemsPerContainer.get();
        int max = WorldLootConfig.SERVER.maxItemsPerContainer.get();
        if (min > max) { int t = min; min = max; max = t; }
        int count = min + (max > min ? RNG.nextInt(max - min + 1) : 0);

        List<Integer> slots = new ArrayList<>(size);
        for (int i = 0; i < size; i++) slots.add(i);
        Collections.shuffle(slots, RNG);

        int placed = 0;
        for (int si = 0; si < slots.size() && placed < count; si++) {
            int slot = slots.get(si);
            if (!inv.getItem(slot).isEmpty()) continue;

            LootEntry entry = reg.pickFromPool(poolName, RNG);
            if (entry == null) break;

            Item item = ForgeRegistries.ITEMS.getValue(entry.itemId);
            if (item == null) continue;

            int stackSize = Math.min(entry.count, item.getMaxStackSize());
            inv.setItem(slot, new ItemStack(item, stackSize));
            placed++;
        }
    }
}

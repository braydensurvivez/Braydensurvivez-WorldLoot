package com.braydensurvivez.worldloot;

import com.braydensurvivez.worldloot.command.WorldLootCommand;
import com.braydensurvivez.worldloot.config.WorldLootConfig;
import com.braydensurvivez.worldloot.loot.ContainerInteractHandler;
import com.braydensurvivez.worldloot.loot.LootPoolRegistry;
import com.braydensurvivez.worldloot.data.TurnBackTimeData;
import com.braydensurvivez.worldloot.loot.TurnBackTimeEngine;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ChunkEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(WorldLootMod.MOD_ID)
public class WorldLootMod {

    public static final String MOD_ID = "worldloot";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    private static final LootPoolRegistry POOL_REGISTRY = new LootPoolRegistry();

    public static LootPoolRegistry getPoolRegistry() {
        return POOL_REGISTRY;
    }

    public WorldLootMod(FMLJavaModLoadingContext context) {
        context.registerConfig(ModConfig.Type.SERVER, WorldLootConfig.SERVER_SPEC, "worldloot-server.toml");

        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);
        MinecraftForge.EVENT_BUS.addListener(this::onServerStarted);
        MinecraftForge.EVENT_BUS.addListener(this::onConfigReload);
        MinecraftForge.EVENT_BUS.addListener(this::onRightClickBlock);
        MinecraftForge.EVENT_BUS.addListener(this::onBlockPlace);
        MinecraftForge.EVENT_BUS.addListener(this::onServerTick);
        MinecraftForge.EVENT_BUS.addListener(this::onChunkLoad);

        LOGGER.info("[WorldLoot] Mod initialised.");
    }

    // ── In-memory sweeper flag ─────────────────────────────────────────────────

    private static volatile boolean globalSweeperEnabled = false;

    public static void setGlobalSweeperEnabled(boolean enabled) {
        globalSweeperEnabled = enabled;
    }

    public static boolean isGlobalSweeperEnabled() {
        return globalSweeperEnabled;
    }

    // ── Events ─────────────────────────────────────────────────────────────────

    private void onRegisterCommands(RegisterCommandsEvent event) {
        WorldLootCommand.register(event.getDispatcher());
        LOGGER.info("[WorldLoot] Commands registered.");
    }

    private void onServerStarted(ServerStartedEvent event) {
        POOL_REGISTRY.reload();
        LOGGER.info("[WorldLoot] Loot pools loaded: {}", POOL_REGISTRY.getPoolNames());
    }

    private void onConfigReload(net.minecraftforge.fml.event.config.ModConfigEvent.Reloading event) {
        if (event.getConfig().getModId().equals(MOD_ID)) {
            POOL_REGISTRY.reload();
            LOGGER.info("[WorldLoot] Config reloaded — loot pools refreshed: {}", POOL_REGISTRY.getPoolNames());
        }
    }

    private void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        ContainerInteractHandler.onRightClickBlock(event);
    }

    private void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        ContainerInteractHandler.onBlockPlace(event);
    }

    /**
     * Chunk-load hook: enqueues the newly loaded chunk for cleaning next tick.
     * Instant return — no work done here.
     */
    private void onChunkLoad(ChunkEvent.Load event) {
        if (!(event.getLevel() instanceof ServerLevel level)) return;
        if (!(event.getChunk() instanceof LevelChunk chunk)) return;
        TurnBackTimeEngine.onChunkLoad(level, chunk);
    }

    // Sweep every 200 ticks = 10 seconds.
    private static final int SWEEP_INTERVAL = 200;
    private int tickCounter = 0;

    private void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        // Drain the work queue every tick — at most CHUNKS_PER_TICK chunks scanned.
        // This is always active so queued work from chunk-load and sweep both drain.
        TurnBackTimeEngine.tickWorkQueue();

        tickCounter++;
        if (tickCounter < SWEEP_INTERVAL) return;
        tickCounter = 0;

        // Re-sync persisted enabled flag every cycle.
        net.minecraft.server.MinecraftServer server =
                net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server != null) {
            TurnBackTimeData data = TurnBackTimeData.get(server.overworld());
            globalSweeperEnabled = data.isGlobalEnabled();
        }

        if (!globalSweeperEnabled) return;
        if (server == null) return;

        // Enqueue the 11×11 area around each player — drains over the next ~12 ticks.
        TurnBackTimeEngine.enqueueSweepAroundPlayers(server);
    }
}

package com.braydensurvivez.worldloot.data;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Persists which (dimension, BlockPos) pairs have already been populated.
 * Stored in the overworld's data folder as "worldloot_tracker".
 */
public class DeploymentTracker extends SavedData {

    private static final String DATA_NAME = WorldLootMod.MOD_ID + "_tracker";

    /** dimension ResourceLocation → set of populated BlockPos */
    private final Map<ResourceLocation, Set<BlockPos>> populated = new HashMap<>();

    // ── Factory / load ─────────────────────────────────────────────────────────

    public static DeploymentTracker get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(
                DeploymentTracker::load,
                DeploymentTracker::new,
                DATA_NAME
        );
    }

    public DeploymentTracker() { }

    private static DeploymentTracker load(CompoundTag tag) {
        DeploymentTracker tracker = new DeploymentTracker();
        ListTag dims = tag.getList("dimensions", Tag.TAG_COMPOUND);
        for (Tag dimTag : dims) {
            CompoundTag dimCompound = (CompoundTag) dimTag;
            ResourceLocation dimKey = ResourceLocation.tryParse(dimCompound.getString("dim"));
            Set<BlockPos> positions = new HashSet<>();
            ListTag posList = dimCompound.getList("positions", Tag.TAG_LONG);
            for (Tag posTag : posList) {
                positions.add(BlockPos.of(((net.minecraft.nbt.LongTag) posTag).getAsLong()));
            }
            tracker.populated.put(dimKey, positions);
        }
        return tracker;
    }

    // ── Save ───────────────────────────────────────────────────────────────────

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag dims = new ListTag();
        for (Map.Entry<ResourceLocation, Set<BlockPos>> entry : populated.entrySet()) {
            CompoundTag dimCompound = new CompoundTag();
            dimCompound.putString("dim", entry.getKey().toString());
            ListTag posList = new ListTag();
            for (BlockPos pos : entry.getValue()) {
                posList.add(net.minecraft.nbt.LongTag.valueOf(pos.asLong()));
            }
            dimCompound.put("positions", posList);
            dims.add(dimCompound);
        }
        tag.put("dimensions", dims);
        return tag;
    }

    // ── API ────────────────────────────────────────────────────────────────────

    public boolean isPopulated(ResourceLocation dimension, BlockPos pos) {
        Set<BlockPos> set = populated.get(dimension);
        return set != null && set.contains(pos);
    }

    public void markPopulated(ResourceLocation dimension, BlockPos pos) {
        populated.computeIfAbsent(dimension, k -> new HashSet<>()).add(pos);
        setDirty();
    }

    /** Wipe all tracking data (used by /braydensurvivezloot reset). */
    public void clearAll() {
        populated.clear();
        setDirty();
    }

    public int totalTracked() {
        return populated.values().stream().mapToInt(Set::size).sum();
    }
}

package com.braydensurvivez.worldloot.loot;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * TurnBackTimeEngine — removes player-placed vines and persistent leaves.
 *
 * Performance model
 * -----------------
 * Work is spread across ticks via a budget queue so no single tick ever
 * does more than CHUNKS_PER_TICK full chunk scans (~10 ms budget).
 *
 * Every 200 ticks (10 s) the sweep enqueues a 10×10 chunk area around each
 * online player.  The queue drains at 10 chunks/tick, so 100 chunks clears
 * in ~10 ticks (0.5 s) — well within the next sweep window.
 *
 * Key perf optimisation: each chunk section (16×16×16 sub-cube) is checked
 * for emptiness before iterating its blocks.  Air-only sections are skipped
 * entirely, cutting iteration cost dramatically in typical worlds.
 *
 * Chunk-load hook → enqueues the single chunk (processed next tick).
 * Periodic sweep  → enqueues 10×10 area around players; queue drains smoothly.
 * Radius command  → enqueues the requested area into the same queue.
 */
public class TurnBackTimeEngine {

    // ── Tunables ───────────────────────────────────────────────────────────────

    /** Chunks processed per server tick. 10 chunks ≈ 10×16×16×384 = ~1M block
     *  reads max, typically <3 ms.  Raise to 15 if you have CPU headroom. */
    private static final int CHUNKS_PER_TICK = 10;

    /** Chunk-radius around each player the sweep covers.
     *  Radius 5 → 11×11 = 121 chunks = 176×176 block area per player. */
    private static final int PLAYER_CHUNK_RADIUS = 5;

    // ── Work queue ─────────────────────────────────────────────────────────────

    private record ChunkWork(ServerLevel level, ChunkPos pos) {}

    /** All pending scan work.  Populated by sweep/load hooks, drained each tick. */
    private static final Deque<ChunkWork> WORK_QUEUE = new ArrayDeque<>();

    /** Tracks which chunks are already in the queue to avoid duplicate entries. */
    private static final Set<Long> QUEUED_KEYS = new HashSet<>();

    private static long chunkKey(int dim, int x, int z) {
        // Pack dimension ordinal + chunk coords into a long for fast dedup.
        // dim is kept small (overworld=0, nether=1, end=2).
        return ((long)(dim & 0xFFFF) << 48) | ((long)(x & 0xFFFFFF) << 24) | (z & 0xFFFFFF);
    }

    // ── Result record ──────────────────────────────────────────────────────────

    public static class ClearResult {
        public int chunksScanned     = 0;
        public int blocksRemoved     = 0;
        public int dimensionsScanned = 0;
    }

    // ── Block filter ──────────────────────────────────────────────────────────

    private static boolean isTargetBlock(BlockState state) {
        Block b = state.getBlock();
        if (b == Blocks.VINE)                                                       return true;
        if (b == Blocks.CAVE_VINES         || b == Blocks.CAVE_VINES_PLANT)        return true;
        if (b == Blocks.TWISTING_VINES     || b == Blocks.TWISTING_VINES_PLANT)    return true;
        if (b == Blocks.WEEPING_VINES      || b == Blocks.WEEPING_VINES_PLANT)     return true;
        if (b == Blocks.GLOW_LICHEN)                                                return true;
        if (state.hasProperty(LeavesBlock.PERSISTENT)) {
            return state.getValue(LeavesBlock.PERSISTENT);
        }
        return false;
    }

    // ── Core: scan one chunk ──────────────────────────────────────────────────

    /**
     * Scans a single chunk section-by-section, skipping empty sections entirely.
     * Collects all target block positions then removes them in one pass.
     */
    private static int scanChunk(ServerLevel level, ChunkPos cp) {
        LevelChunk lc = level.getChunkSource().getChunkNow(cp.x, cp.z);
        if (lc == null) return 0;

        List<BlockPos> toRemove = new ArrayList<>();
        int baseX = cp.getMinBlockX();
        int baseZ = cp.getMinBlockZ();
        int minY  = level.getMinBuildHeight();

        LevelChunkSection[] sections = lc.getSections();
        BlockPos.MutableBlockPos mutable = new BlockPos.MutableBlockPos();

        for (int si = 0; si < sections.length; si++) {
            LevelChunkSection section = sections[si];
            // Skip completely empty sections — no blocks to check.
            if (section == null || section.hasOnlyAir()) continue;

            int sectionBaseY = minY + si * 16;

            for (int lx = 0; lx < 16; lx++) {
                for (int lz = 0; lz < 16; lz++) {
                    for (int ly = 0; ly < 16; ly++) {
                        BlockState state = section.getBlockState(lx, ly, lz);
                        if (state.isAir()) continue;
                        if (isTargetBlock(state)) {
                            toRemove.add(new BlockPos(baseX + lx, sectionBaseY + ly, baseZ + lz));
                        }
                    }
                }
            }
        }

        for (BlockPos pos : toRemove) {
            level.removeBlock(pos, false);
        }
        return toRemove.size();
    }

    // ── Enqueue helper ────────────────────────────────────────────────────────

    private static void enqueue(ServerLevel level, ChunkPos cp) {
        // Use the level's registry key hashCode as a cheap dim id.
        int dimId = level.dimension().location().hashCode();
        long key  = chunkKey(dimId, cp.x, cp.z);
        if (QUEUED_KEYS.add(key)) {           // add returns false if already present
            WORK_QUEUE.addLast(new ChunkWork(level, cp));
        }
    }

    // ── Per-tick budget drain ─────────────────────────────────────────────────

    /**
     * Call every server tick.  Processes at most {@value #CHUNKS_PER_TICK}
     * chunks so the server tick time stays bounded.
     */
    public static void tickWorkQueue() {
        int processed = 0;
        while (processed < CHUNKS_PER_TICK && !WORK_QUEUE.isEmpty()) {
            ChunkWork work = WORK_QUEUE.poll();
            // Remove from dedup set so this chunk can be re-queued next sweep.
            int dimId = work.level().dimension().location().hashCode();
            QUEUED_KEYS.remove(chunkKey(dimId, work.pos().x, work.pos().z));

            int removed = scanChunk(work.level(), work.pos());
            if (removed > 0) {
                WorldLootMod.LOGGER.debug(
                        "[WorldLoot/TurnBackTime] Cleaned {}: {} block(s) removed.",
                        work.pos(), removed);
            }
            processed++;
        }
    }

    // ── Chunk-load hook ───────────────────────────────────────────────────────

    /**
     * Enqueues a freshly-loaded chunk for cleaning next tick.
     */
    public static void onChunkLoad(ServerLevel level, LevelChunk chunk) {
        if (!WorldLootMod.isGlobalSweeperEnabled()) return;
        enqueue(level, chunk.getPos());
    }

    // ── Periodic sweep ────────────────────────────────────────────────────────

    /**
     * Enqueues all loaded chunks within {@value #PLAYER_CHUNK_RADIUS} chunks of
     * every online player.  The actual scanning is spread across future ticks
     * by {@link #tickWorkQueue()}.
     *
     * Called every 200 ticks (10 s) from WorldLootMod.
     */
    public static void enqueueSweepAroundPlayers(MinecraftServer server) {
        int enqueued = 0;
        for (ServerLevel level : server.getAllLevels()) {
            for (net.minecraft.world.entity.player.Player player : level.players()) {
                ChunkPos pc = new ChunkPos(player.blockPosition());
                for (int dx = -PLAYER_CHUNK_RADIUS; dx <= PLAYER_CHUNK_RADIUS; dx++) {
                    for (int dz = -PLAYER_CHUNK_RADIUS; dz <= PLAYER_CHUNK_RADIUS; dz++) {
                        ChunkPos cp = new ChunkPos(pc.x + dx, pc.z + dz);
                        if (level.getChunkSource().getChunkNow(cp.x, cp.z) != null) {
                            enqueue(level, cp);
                            enqueued++;
                        }
                    }
                }
            }
        }
        if (enqueued > 0) {
            WorldLootMod.LOGGER.debug(
                    "[WorldLoot/TurnBackTime] Sweep enqueued {} chunk(s) (queue depth: {}).",
                    enqueued, WORK_QUEUE.size());
        }
    }

    // ── Radius command ────────────────────────────────────────────────────────

    /**
     * Enqueues all loaded chunks within {@code radius} blocks of {@code center}.
     */
    public static ClearResult enqueueRadius(ServerLevel level, BlockPos center, int radius) {
        ClearResult result = new ClearResult();
        result.dimensionsScanned = 1;

        int minCX = (center.getX() - radius) >> 4;
        int maxCX = (center.getX() + radius) >> 4;
        int minCZ = (center.getZ() - radius) >> 4;
        int maxCZ = (center.getZ() + radius) >> 4;

        for (int cx = minCX; cx <= maxCX; cx++) {
            for (int cz = minCZ; cz <= maxCZ; cz++) {
                if (level.getChunkSource().getChunkNow(cx, cz) != null) {
                    enqueue(level, new ChunkPos(cx, cz));
                    result.chunksScanned++;
                }
            }
        }

        WorldLootMod.LOGGER.info(
                "[WorldLoot/TurnBackTime] Radius command: enqueued {} chunk(s) within {} blocks.",
                result.chunksScanned, radius);
        return result;
    }

    /** Queue depth — used by commands for feedback. */
    public static int getQueueDepth() {
        return WORK_QUEUE.size();
    }
}

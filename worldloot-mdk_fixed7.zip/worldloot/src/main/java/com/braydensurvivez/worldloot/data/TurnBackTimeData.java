package com.braydensurvivez.worldloot.data;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Persists the "turnbacktime global" enabled flag across restarts.
 *
 * When enabled, a server-tick listener fires every TICK_INTERVAL ticks
 * and removes player-placed vines/leaves from all loaded chunks.
 */
public class TurnBackTimeData extends SavedData {

    private static final String DATA_NAME = WorldLootMod.MOD_ID + "_turnbacktime";

    /** Whether the global passive cleaner is running. */
    private boolean globalEnabled = false;

    /** Radius (in blocks) used by the one-shot command. Default 64. */
    private int radius = 64;

    // ── Factory / load ─────────────────────────────────────────────────────────

    public static TurnBackTimeData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(
                TurnBackTimeData::load,
                TurnBackTimeData::new,
                DATA_NAME
        );
    }

    public TurnBackTimeData() { }

    private static TurnBackTimeData load(CompoundTag tag) {
        TurnBackTimeData data = new TurnBackTimeData();
        data.globalEnabled = tag.getBoolean("globalEnabled");
        if (tag.contains("radius")) {
            data.radius = tag.getInt("radius");
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        tag.putBoolean("globalEnabled", globalEnabled);
        tag.putInt("radius", radius);
        return tag;
    }

    // ── API ────────────────────────────────────────────────────────────────────

    public boolean isGlobalEnabled() { return globalEnabled; }

    public void setGlobalEnabled(boolean enabled) {
        this.globalEnabled = enabled;
        setDirty();
    }

    public int getRadius() { return radius; }

    public void setRadius(int radius) {
        this.radius = radius;
        setDirty();
    }
}

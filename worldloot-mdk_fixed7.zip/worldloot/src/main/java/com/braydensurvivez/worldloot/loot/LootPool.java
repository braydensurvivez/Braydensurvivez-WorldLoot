package com.braydensurvivez.worldloot.loot;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Parses "modid:item_id,count,weight" config strings into weighted entries
 * and provides a weighted-random pick method.
 *
 * Format: "modid:item_id,count,weight"
 *   - item_id : registry name of the item  (e.g. "minecraft:bread")
 *   - count   : stack size to spawn        (e.g. 3)
 *   - weight  : relative spawn chance      (e.g. 50)
 *
 * Legacy two-field format "modid:item_id,weight" is still accepted for
 * backwards compatibility and defaults count to 1.
 */
public class LootPool {

    private final List<LootEntry> entries = new ArrayList<>();
    private int totalWeight = 0;
    private int invalidEntries = 0;
    private final String poolName;

    public LootPool(String poolName, List<? extends String> rawEntries) {
        this.poolName = poolName;
        for (String raw : rawEntries) {
            parse(raw.trim());
        }
    }

    private void parse(String raw) {
        try {
            // Split on commas – we expect either 2 or 3 parts
            String[] parts = raw.split(",");

            if (parts.length < 2) {
                WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': entry '{}' must have at least item and weight – skipping.", poolName, raw);
                invalidEntries++;
                return;
            }

            String idStr;
            int count;
            int weight;

            if (parts.length == 2) {
                // Legacy format: "item,weight"  →  count defaults to 1
                idStr  = parts[0].trim();
                count  = 1;
                weight = Integer.parseInt(parts[1].trim());
            } else {
                // New format: "item,count,weight"
                idStr  = parts[0].trim();
                count  = Integer.parseInt(parts[1].trim());
                weight = Integer.parseInt(parts[2].trim());
            }

            if (count <= 0) {
                WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': count must be > 0 for '{}' – skipping.", poolName, raw);
                invalidEntries++;
                return;
            }
            if (weight <= 0) {
                WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': weight must be > 0 for '{}' – skipping.", poolName, raw);
                invalidEntries++;
                return;
            }

            ResourceLocation rl = ResourceLocation.tryParse(idStr);
            if (rl == null) {
                WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': invalid resource location '{}' – skipping.", poolName, idStr);
                invalidEntries++;
                return;
            }
            if (!ForgeRegistries.ITEMS.containsKey(rl)) {
                WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': unknown item '{}' – skipping.", poolName, idStr);
                invalidEntries++;
                return;
            }

            entries.add(new LootEntry(rl, count, weight));
            totalWeight += weight;

        } catch (NumberFormatException e) {
            WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': failed to parse number in entry '{}': {} – skipping.", poolName, raw, e.getMessage());
            invalidEntries++;
        } catch (Exception e) {
            WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': failed to parse entry '{}': {} – skipping.", poolName, raw, e.getMessage());
            invalidEntries++;
        }
    }

    /** Pick a random entry by weight. Returns null if pool is empty. */
    public LootEntry pick(Random rng) {
        if (entries.isEmpty()) return null;
        int roll = rng.nextInt(totalWeight);
        int cumulative = 0;
        for (LootEntry entry : entries) {
            cumulative += entry.weight;
            if (roll < cumulative) return entry;
        }
        return entries.get(entries.size() - 1); // fallback
    }

    public boolean isEmpty()          { return entries.isEmpty(); }
    public int size()                 { return entries.size(); }
    public int getInvalidEntries()    { return invalidEntries; }
    public String getName()           { return poolName; }
}

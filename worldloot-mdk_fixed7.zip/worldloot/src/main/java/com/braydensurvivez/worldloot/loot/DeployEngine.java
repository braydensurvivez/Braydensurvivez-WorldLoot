package com.braydensurvivez.worldloot.loot;

import com.braydensurvivez.worldloot.WorldLootMod;
import com.braydensurvivez.worldloot.config.WorldLootConfig;
import com.braydensurvivez.worldloot.data.DeploymentTracker;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * Handles manual (command-triggered) deployments only.
 * The passive loot system now lives in ContainerInteractHandler (right-click trigger).
 */
public class DeployEngine {

    private static final Set<String> DEFAULT_ALLOWED = Set.of(
            "minecraft:chest",
            "minecraft:trapped_chest",
            "minecraft:barrel",
            "minecraft:shulker_box",
            "minecraft:white_shulker_box",
            "minecraft:orange_shulker_box",
            "minecraft:magenta_shulker_box",
            "minecraft:light_blue_shulker_box",
            "minecraft:yellow_shulker_box",
            "minecraft:lime_shulker_box",
            "minecraft:pink_shulker_box",
            "minecraft:gray_shulker_box",
            "minecraft:light_gray_shulker_box",
            "minecraft:cyan_shulker_box",
            "minecraft:purple_shulker_box",
            "minecraft:blue_shulker_box",
            "minecraft:brown_shulker_box",
            "minecraft:green_shulker_box",
            "minecraft:red_shulker_box",
            "minecraft:black_shulker_box"
    );

    private final Random rng = new Random();

    public DeployEngine() { }

    // ── Public entry points ────────────────────────────────────────────────────

    /**
     * Returns only the ServerLevels that currently have at least one player in them.
     * This prevents scanning empty dimensions (Nether, End, etc.) when no one is there.
     */
    private List<ServerLevel> getOccupiedLevels(MinecraftServer server) {
        List<ServerLevel> occupied = new ArrayList<>();
        for (ServerLevel level : server.getAllLevels()) {
            if (!level.players().isEmpty()) {
                occupied.add(level);
            }
        }
        // Fall back to overworld if somehow no level has players (e.g. no one online yet)
        if (occupied.isEmpty()) {
            occupied.add(server.overworld());
        }
        return occupied;
    }

    /** Normal deploy: scans loaded chunks only in dimensions where players are present. */
    public DeployResult deploy(MinecraftServer server, boolean force) {
        LootPoolRegistry poolRegistry = com.braydensurvivez.worldloot.WorldLootMod.getPoolRegistry();
        DeploymentTracker tracker = DeploymentTracker.get(server.overworld());
        DeployResult result = new DeployResult();

        Set<String> blacklist = resolveList(WorldLootConfig.SERVER.containerBlacklist.get());
        Set<String> whitelist = resolveList(WorldLootConfig.SERVER.containerWhitelist.get());

        for (ServerLevel level : getOccupiedLevels(server)) {
            result.dimensionsScanned++;
            ResourceLocation dimKey = level.dimension().location();

            for (LevelChunk chunk : collectLoadedChunks(level)) {
                result.chunksScanned++;
                for (Map.Entry<BlockPos, BlockEntity> entry : chunk.getBlockEntities().entrySet()) {
                    BlockPos pos = entry.getKey();
                    BlockEntity be = entry.getValue();
                    if (!(be instanceof Container)) continue;
                    result.containersFound++;
                    if (!force && tracker.isPopulated(dimKey, pos)) { result.containersSkipped++; continue; }
                    if (!isContainerTypeAllowed(be, blacklist, whitelist)) { result.containersSkipped++; continue; }
                    if (!checkContainerFlags(be)) { result.containersSkipped++; continue; }
                    Container inv = (Container) be;
                    if (WorldLootConfig.SERVER.populateEmptyOnly.get() && !isContainerEmpty(inv)) { result.containersSkipped++; continue; }
                    fillContainer(inv, null);
                    tracker.markPopulated(dimKey, pos);
                    result.containersPopulated++;
                }
            }
        }

        result.invalidRegistryEntries = poolRegistry.totalInvalidEntries();
        logResult(result, force, null, null);
        return result;
    }

    /**
     * Targeted deploy: fills only containers matching a specific block ID,
     * using only the named loot pool.
     */
    public DeployResult deployTargeted(MinecraftServer server, boolean force,
                                       String targetBlockId, String poolName) {
        LootPoolRegistry poolRegistry = com.braydensurvivez.worldloot.WorldLootMod.getPoolRegistry();
        DeploymentTracker tracker = DeploymentTracker.get(server.overworld());
        DeployResult result = new DeployResult();
        String targetId = targetBlockId.trim().toLowerCase();

        for (ServerLevel level : getOccupiedLevels(server)) {
            result.dimensionsScanned++;
            ResourceLocation dimKey = level.dimension().location();

            for (LevelChunk chunk : collectLoadedChunks(level)) {
                result.chunksScanned++;
                for (Map.Entry<BlockPos, BlockEntity> entry : chunk.getBlockEntities().entrySet()) {
                    BlockPos pos = entry.getKey();
                    BlockEntity be = entry.getValue();
                    if (!(be instanceof Container)) continue;
                    result.containersFound++;
                    ResourceLocation blockId = ForgeRegistries.BLOCKS.getKey(be.getBlockState().getBlock());
                    if (blockId == null || !blockId.toString().toLowerCase().equals(targetId)) { result.containersSkipped++; continue; }
                    if (!force && tracker.isPopulated(dimKey, pos)) { result.containersSkipped++; continue; }
                    if (!checkContainerFlags(be)) { result.containersSkipped++; continue; }
                    Container inv = (Container) be;
                    if (WorldLootConfig.SERVER.populateEmptyOnly.get() && !isContainerEmpty(inv)) { result.containersSkipped++; continue; }
                    fillContainer(inv, poolName);
                    tracker.markPopulated(dimKey, pos);
                    result.containersPopulated++;
                }
            }
        }

        result.invalidRegistryEntries = poolRegistry.totalInvalidEntries();
        logResult(result, force, targetBlockId, poolName);
        return result;
    }

    public void reset(MinecraftServer server) {
        DeploymentTracker tracker = DeploymentTracker.get(server.overworld());
        int before = tracker.totalTracked();
        tracker.clearAll();
        WorldLootMod.LOGGER.info("[WorldLoot] RESET: cleared {} tracked container entries.", before);
    }

    /** Expose pool names so the command can tab-complete them. */
    public Set<String> getPoolNames() {
        return com.braydensurvivez.worldloot.WorldLootMod.getPoolRegistry().getPoolNames();
    }

    // ── Container type filtering ───────────────────────────────────────────────

    private static Set<String> resolveList(List<? extends String> raw) {
        Set<String> out = new HashSet<>();
        for (String s : raw) { String t = s.trim().toLowerCase(); if (!t.isEmpty()) out.add(t); }
        return out;
    }

    private boolean isContainerTypeAllowed(BlockEntity be, Set<String> blacklist, Set<String> whitelist) {
        ResourceLocation blockId = ForgeRegistries.BLOCKS.getKey(be.getBlockState().getBlock());
        if (blockId == null) return false;
        String id = blockId.toString().toLowerCase();
        if (blacklist.contains(id)) return false;
        if (whitelist.contains(id)) return true;
        return DEFAULT_ALLOWED.contains(id);
    }

    // ── Chunk collection ──────────────────────────────────────────────────────

    private List<LevelChunk> collectLoadedChunks(ServerLevel level) {
        Map<Long, LevelChunk> seen = new HashMap<>();
        int simDistance = Math.max(level.getServer().getPlayerList().getSimulationDistance(), 4);
        for (var player : level.players()) {
            int pcx = player.chunkPosition().x;
            int pcz = player.chunkPosition().z;
            for (int dx = -simDistance; dx <= simDistance; dx++)
                for (int dz = -simDistance; dz <= simDistance; dz++)
                    probeChunk(level, seen, pcx + dx, pcz + dz);
        }
        int spawnCx = level.getLevelData().getXSpawn() >> 4;
        int spawnCz = level.getLevelData().getZSpawn() >> 4;
        for (int dx = -8; dx <= 8; dx++)
            for (int dz = -8; dz <= 8; dz++)
                probeChunk(level, seen, spawnCx + dx, spawnCz + dz);
        level.getForcedChunks().forEach(packedPos ->
                probeChunk(level, seen, ChunkPos.getX(packedPos), ChunkPos.getZ(packedPos)));
        return new ArrayList<>(seen.values());
    }

    private void probeChunk(ServerLevel level, Map<Long, LevelChunk> seen, int cx, int cz) {
        long key = ChunkPos.asLong(cx, cz);
        if (seen.containsKey(key)) return;
        ChunkAccess ca = level.getChunkSource().getChunk(cx, cz, ChunkStatus.FULL, false);
        if (ca instanceof LevelChunk lc) seen.put(key, lc);
    }

    // ── Container eligibility ─────────────────────────────────────────────────

    private boolean checkContainerFlags(BlockEntity be) {
        if (WorldLootConfig.SERVER.ignoreLockedContainers.get()
                && be instanceof BaseContainerBlockEntity base) {
            try {
                java.lang.reflect.Field f = BaseContainerBlockEntity.class.getDeclaredField("lockKey");
                f.setAccessible(true);
                net.minecraft.world.LockCode lock = (net.minecraft.world.LockCode) f.get(base);
                if (lock != null) {
                    net.minecraft.nbt.CompoundTag lockTag = new net.minecraft.nbt.CompoundTag();
                    lock.addToTag(lockTag);
                    if (!lockTag.getString("Lock").isEmpty()) return false;
                }
            } catch (Exception ignored) { }
        }
        return true;
    }

    private boolean isContainerEmpty(Container inv) {
        for (int i = 0; i < inv.getContainerSize(); i++)
            if (!inv.getItem(i).isEmpty()) return false;
        return true;
    }

    // ── Loot filling ──────────────────────────────────────────────────────────

    private void fillContainer(Container inv, String poolName) {
        int size = inv.getContainerSize();
        if (size == 0) return;
        if (WorldLootConfig.SERVER.clearContainerBeforeFill.get()) inv.clearContent();
        int min = WorldLootConfig.SERVER.minItemsPerContainer.get();
        int max = WorldLootConfig.SERVER.maxItemsPerContainer.get();
        if (min > max) { int t = min; min = max; max = t; }
        int count = min + (max > min ? rng.nextInt(max - min + 1) : 0);
        List<Integer> slots = new ArrayList<>(size);
        for (int i = 0; i < size; i++) slots.add(i);
        Collections.shuffle(slots, rng);
        LootPoolRegistry reg = com.braydensurvivez.worldloot.WorldLootMod.getPoolRegistry();
        int placed = 0;
        for (int si = 0; si < slots.size() && placed < count; si++) {
            int slot = slots.get(si);
            if (!inv.getItem(slot).isEmpty()) continue;
            LootEntry entry = (poolName != null)
                    ? reg.pickFromPool(poolName, rng)
                    : reg.pickAny(rng);
            if (entry == null) break;
            Item item = ForgeRegistries.ITEMS.getValue(entry.itemId);
            if (item == null) continue;
            // Clamp count to the item's max stack size so we never create illegal stacks
            int stackSize = Math.min(entry.count, item.getMaxStackSize());
            inv.setItem(slot, new ItemStack(item, stackSize));
            placed++;
        }
    }

    // ── Logging ───────────────────────────────────────────────────────────────

    private void logResult(DeployResult r, boolean force, String targetBlock, String pool) {
        WorldLootMod.LOGGER.info("====================================");
        if (targetBlock != null) {
            WorldLootMod.LOGGER.info("[WorldLoot] Targeted deploy {} → block='{}' pool='{}'",
                    force ? "(FORCE)" : "", targetBlock, pool);
        } else {
            WorldLootMod.LOGGER.info("[WorldLoot] Deploy {} complete.", force ? "(FORCE)" : "");
        }
        WorldLootMod.LOGGER.info("  Dimensions scanned  : {}", r.dimensionsScanned);
        WorldLootMod.LOGGER.info("  Chunks scanned      : {}", r.chunksScanned);
        WorldLootMod.LOGGER.info("  Containers found    : {}", r.containersFound);
        WorldLootMod.LOGGER.info("  Containers populated: {}", r.containersPopulated);
        WorldLootMod.LOGGER.info("  Containers skipped  : {}", r.containersSkipped);
        WorldLootMod.LOGGER.info("  Invalid registry IDs: {}", r.invalidRegistryEntries);
        WorldLootMod.LOGGER.info("====================================");
    }

    // ── Result record ─────────────────────────────────────────────────────────

    public static class DeployResult {
        public int dimensionsScanned;
        public int chunksScanned;
        public int containersFound;
        public int containersPopulated;
        public int containersSkipped;
        public int invalidRegistryEntries;
    }
}

package com.braydensurvivez.worldloot.data;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Persists global block→pool assignments created by:
 *   /braydensurvivezloot deploy global <block> <pool>
 *
 * Any container whose block type has an entry here will be filled with
 * that pool when its chunk is loaded (or when a normal deploy runs).
 *
 * Running the command again for the same block type REPLACES the assignment.
 * Running /braydensurvivezloot deploy global <block> clear  removes it.
 */
public class GlobalAssignmentData extends SavedData {

    private static final String DATA_NAME = WorldLootMod.MOD_ID + "_global_assignments";

    /** block registry name → pool name */
    private final Map<String, String> assignments = new LinkedHashMap<>();

    // ── Factory / load ─────────────────────────────────────────────────────────

    public static GlobalAssignmentData get(ServerLevel overworld) {
        return overworld.getDataStorage().computeIfAbsent(
                GlobalAssignmentData::load,
                GlobalAssignmentData::new,
                DATA_NAME
        );
    }

    public GlobalAssignmentData() { }

    private static GlobalAssignmentData load(CompoundTag tag) {
        GlobalAssignmentData data = new GlobalAssignmentData();
        CompoundTag map = tag.getCompound("assignments");
        for (String blockId : map.getAllKeys()) {
            data.assignments.put(blockId, map.getString(blockId));
        }
        return data;
    }

    // ── Save ───────────────────────────────────────────────────────────────────

    @Override
    public CompoundTag save(CompoundTag tag) {
        CompoundTag map = new CompoundTag();
        assignments.forEach(map::putString);
        tag.put("assignments", map);
        return tag;
    }

    // ── API ────────────────────────────────────────────────────────────────────

    /** Set (or replace) the pool assignment for a block type. */
    public void assign(String blockId, String poolName) {
        assignments.put(blockId.trim().toLowerCase(), poolName.trim());
        setDirty();
    }

    /** Remove the assignment for a block type. Returns true if it existed. */
    public boolean remove(String blockId) {
        boolean existed = assignments.remove(blockId.trim().toLowerCase()) != null;
        if (existed) setDirty();
        return existed;
    }

    /**
     * Returns the pool name assigned to this block, or null if none.
     * @param blockId registry name, e.g. "minecraft:trapped_chest"
     */
    public String getPool(String blockId) {
        return assignments.get(blockId.trim().toLowerCase());
    }

    /** All current assignments (unmodifiable view). */
    public Map<String, String> getAll() {
        return Collections.unmodifiableMap(assignments);
    }

    public void clearAll() {
        assignments.clear();
        setDirty();
    }
}

package com.braydensurvivez.worldloot.config;

import com.braydensurvivez.worldloot.WorldLootMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Loads custom loot pools from JSON files in config/worldloot/pools/.
 *
 * File format (e.g. "my_pool.json"):
 * <pre>
 * {
 *   "description": "My custom pool description",
 *   "entries": [
 *     { "item": "minecraft:diamond_sword", "weight": 10 },
 *     { "item": "minecraft:iron_ingot",    "weight": 40 },
 *     { "item": "mod_id:custom_item",      "weight": 20 }
 *   ]
 * }
 * </pre>
 *
 * The pool name is derived from the filename (without ".json").
 * Files named starting with "_" are treated as example/disabled files and skipped.
 */
public class CustomPoolLoader {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Folder inside the game's config directory. */
    private static final String SUBFOLDER = "worldloot/pools";

    /**
     * Scans the pools directory and returns a map of pool name -> list of "item,weight" strings
     * (same format used by ForgeConfigSpec pools so LootPool can parse them uniformly).
     */
    public static Map<String, List<String>> loadAll(Path configDir) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        Path poolsDir = configDir.resolve(SUBFOLDER);

        ensureDirectoryExists(poolsDir);
        writeDefaultPools(poolsDir);
        writeExampleFiles(poolsDir);

        try {
            Files.list(poolsDir)
                 .filter(p -> p.getFileName().toString().endsWith(".json"))
                 .filter(p -> !p.getFileName().toString().startsWith("_"))
                 .sorted()
                 .forEach(file -> {
                     String name = stripExtension(file.getFileName().toString());
                     List<String> entries = parseFile(file, name);
                     if (entries != null && !entries.isEmpty()) {
                         result.put(name, entries);
                         WorldLootMod.LOGGER.info("[WorldLoot] Loaded custom pool '{}' ({} entries) from {}",
                                 name, entries.size(), file.getFileName());
                     }
                 });
        } catch (IOException e) {
            WorldLootMod.LOGGER.error("[WorldLoot] Failed to list pools directory {}: {}", poolsDir, e.getMessage());
        }

        return result;
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private static void ensureDirectoryExists(Path dir) {
        if (!Files.exists(dir)) {
            try {
                Files.createDirectories(dir);
                WorldLootMod.LOGGER.info("[WorldLoot] Created custom pool directory: {}", dir);
            } catch (IOException e) {
                WorldLootMod.LOGGER.error("[WorldLoot] Could not create pool directory {}: {}", dir, e.getMessage());
            }
        }
    }

    /**
     * Writes the bundled default loot pool JSON files (overall, medical, military,
     * commonsupplies) into the pools directory the first time the server starts.
     * Files are only written if they do not already exist, so server admins can
     * freely customise or delete them without fear of them being overwritten.
     */
    private static final String[] DEFAULT_POOL_FILES = {
            "overall.json",
            "medical.json",
            "military.json",
            "commonsupplies.json"
    };

    private static void writeDefaultPools(Path dir) {
        for (String filename : DEFAULT_POOL_FILES) {
            Path target = dir.resolve(filename);
            if (Files.exists(target)) continue; // never overwrite admin edits
            String resource = "/defaultpools/" + filename;
            try (InputStream in = CustomPoolLoader.class.getResourceAsStream(resource)) {
                if (in == null) {
                    WorldLootMod.LOGGER.warn("[WorldLoot] Could not find bundled pool resource '{}' — skipping.", resource);
                    continue;
                }
                Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
                WorldLootMod.LOGGER.info("[WorldLoot] Wrote default pool file: {}", target.getFileName());
            } catch (IOException e) {
                WorldLootMod.LOGGER.error("[WorldLoot] Failed to write default pool '{}': {}", filename, e.getMessage());
            }
        }
    }

    /**
     * Writes example/template pool files the first time the folder is created.
     * Files are prefixed with "_" so they are skipped during loading — users
     * rename them (remove the leading underscore) to activate them.
     */
    private static void writeExampleFiles(Path dir) {
        writeExampleFile(dir, "_example_custom_pool.json",
                buildExampleJson(
                        "Example custom pool — rename this file (remove the leading _) to activate it. Format: item (registry name), count (stack size to spawn), weight (relative spawn chance).",
                        new String[][]{
                                {"minecraft:iron_ingot",    "3", "40"},
                                {"minecraft:gold_ingot",    "2", "20"},
                                {"minecraft:diamond",       "1", "5"},
                                {"minecraft:emerald",       "1", "8"},
                                {"minecraft:lapis_lazuli",  "5", "25"}
                        }
                ));

        writeExampleFile(dir, "_example_weapons.json",
                buildExampleJson(
                        "Example weapons pool — rename this file (remove the leading _) to activate it. Format: item (registry name), count (stack size to spawn), weight (relative spawn chance).",
                        new String[][]{
                                {"minecraft:stone_sword",   "1", "40"},
                                {"minecraft:iron_sword",    "1", "20"},
                                {"minecraft:golden_sword",  "1", "10"},
                                {"minecraft:diamond_sword", "1", "3"},
                                {"minecraft:bow",           "1", "25"},
                                {"minecraft:arrow",         "16", "30"},
                                {"minecraft:crossbow",      "1", "15"}
                        }
                ));
    }

    private static void writeExampleFile(Path dir, String filename, String content) {
        Path target = dir.resolve(filename);
        if (!Files.exists(target)) {
            try (Writer w = Files.newBufferedWriter(target)) {
                w.write(content);
            } catch (IOException e) {
                WorldLootMod.LOGGER.warn("[WorldLoot] Could not write example file {}: {}", target, e.getMessage());
            }
        }
    }

    /**
     * Builds example JSON. Each item array is { "item", "count", "weight" }.
     * count is the stack size spawned; weight is the relative spawn chance.
     */
    private static String buildExampleJson(String description, String[][] items) {
        JsonObject root = new JsonObject();
        root.addProperty("description", description);
        JsonArray entries = new JsonArray();
        for (String[] triple : items) {
            JsonObject entry = new JsonObject();
            entry.addProperty("item",   triple[0]);
            entry.addProperty("count",  Integer.parseInt(triple[1]));
            entry.addProperty("weight", Integer.parseInt(triple[2]));
            entries.add(entry);
        }
        root.add("entries", entries);
        return GSON.toJson(root);
    }

    /**
     * Parses a single JSON pool file and returns a list of "item,weight" strings.
     * Returns null (and logs a warning) if the file is malformed.
     */
    private static List<String> parseFile(Path file, String poolName) {
        try (Reader reader = Files.newBufferedReader(file)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();

            if (!root.has("entries")) {
                WorldLootMod.LOGGER.warn("[WorldLoot] Pool file '{}' has no 'entries' array — skipping.", file.getFileName());
                return null;
            }

            JsonArray entries = root.getAsJsonArray("entries");
            List<String> result = new ArrayList<>();

            for (JsonElement el : entries) {
                JsonObject obj = el.getAsJsonObject();
                if (!obj.has("item") || !obj.has("weight")) {
                    WorldLootMod.LOGGER.warn("[WorldLoot] Pool '{}': entry missing 'item' or 'weight' field — skipping entry.", poolName);
                    continue;
                }
                String item   = obj.get("item").getAsString().trim();
                int    count  = obj.has("count") ? obj.get("count").getAsInt() : 1;
                int    weight = obj.get("weight").getAsInt();
                // Store as "item,count,weight" so LootPool parses all three fields
                result.add(item + "," + count + "," + weight);
            }

            return result;

        } catch (Exception e) {
            WorldLootMod.LOGGER.error("[WorldLoot] Failed to parse pool file '{}': {}", file.getFileName(), e.getMessage());
            return null;
        }
    }

    private static String stripExtension(String filename) {
        int dot = filename.lastIndexOf('.');
        return dot < 0 ? filename : filename.substring(0, dot);
    }
}

package com.braydensurvivez.worldloot.loot;

import net.minecraft.resources.ResourceLocation;

public class LootEntry {
    public final ResourceLocation itemId;
    public final int count;
    public final int weight;

    public LootEntry(ResourceLocation itemId, int count, int weight) {
        this.itemId  = itemId;
        this.count   = count;
        this.weight  = weight;
    }
}

package com.braydensurvivez.worldloot.config;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class WorldLootConfig {

    public static final ForgeConfigSpec SERVER_SPEC;
    public static final WorldLootConfig SERVER;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        SERVER = new WorldLootConfig(builder);
        SERVER_SPEC = builder.build();
    }

    // ── Behaviour ──────────────────────────────────────────────────────────────
    public final ForgeConfigSpec.BooleanValue clearContainerBeforeFill;
    public final ForgeConfigSpec.BooleanValue affectPlayerPlacedContainers;
    public final ForgeConfigSpec.BooleanValue affectGeneratedContainers;
    public final ForgeConfigSpec.BooleanValue populateEmptyOnly;
    public final ForgeConfigSpec.BooleanValue ignoreLockedContainers;
    public final ForgeConfigSpec.IntValue minItemsPerContainer;
    public final ForgeConfigSpec.IntValue maxItemsPerContainer;

    // ── Container filtering ────────────────────────────────────────────────────
    public final ForgeConfigSpec.ConfigValue<List<? extends String>> containerWhitelist;
    public final ForgeConfigSpec.ConfigValue<List<? extends String>> containerBlacklist;

    // ── Named loot pools ───────────────────────────────────────────────────────
    // Each entry is a named pool stored as a map of name -> ConfigValue<List<String>>
    // We use a fixed set of named pools declared at build time.
    // To add a new pool, add it here and it will appear in the config file.
    public final Map<String, ForgeConfigSpec.ConfigValue<List<? extends String>>> namedPools
            = new LinkedHashMap<>();

    public WorldLootConfig(ForgeConfigSpec.Builder builder) {

        builder.comment("WorldLoot – braydensurvivez").push("behaviour");

        clearContainerBeforeFill = builder
                .comment("Clear a container's existing contents before filling it.")
                .define("clear_container_before_fill", false);

        affectPlayerPlacedContainers = builder
                .comment("Deploy loot into player-placed containers.")
                .define("affect_player_placed_containers", true);

        affectGeneratedContainers = builder
                .comment("Deploy loot into naturally generated containers.")
                .define("affect_generated_containers", true);

        populateEmptyOnly = builder
                .comment("Only populate containers that are currently empty.")
                .define("populate_empty_only", false);

        ignoreLockedContainers = builder
                .comment("Skip containers that are locked (have a lock tag).")
                .define("ignore_locked_containers", true);

        minItemsPerContainer = builder
                .comment("Minimum number of item stacks placed per container.")
                .defineInRange("min_items_per_container", 3, 1, 54);

        maxItemsPerContainer = builder
                .comment("Maximum number of item stacks placed per container.")
                .defineInRange("max_items_per_container", 10, 1, 54);

        builder.pop();

        // ── Container filtering ────────────────────────────────────────────────
        builder.comment(
                "Container filtering. Uses block registry names (e.g. \"minecraft:chest\").",
                "",
                "Resolution order:",
                "  1. If a container's block is on the BLACKLIST  → always skipped.",
                "  2. If a container's block is on the WHITELIST  → always allowed.",
                "  3. Otherwise only the built-in defaults are eligible:",
                "     chest, trapped_chest, barrel, and all shulker box colours.",
                "",
                "NOTE: targeted deploys (/braydensurvivezloot deploy <block> <pool>) bypass",
                "the whitelist/blacklist entirely — you are explicitly naming the target.",
                "",
                "Leave a list empty to have no effect from that list."
        ).push("container_filter");

        containerBlacklist = builder
                .comment(
                        "Containers that will NEVER receive loot during a normal deploy.",
                        "Example: [\"minecraft:trapped_chest\", \"minecraft:hopper\"]"
                )
                .defineList("blacklist", List.of(), e -> e instanceof String);

        containerWhitelist = builder
                .comment(
                        "Extra containers (beyond the defaults) allowed to receive loot.",
                        "Useful for modded storage blocks, e.g. \"ironchest:iron_chest\"."
                )
                .defineList("whitelist", List.of(), e -> e instanceof String);

        builder.pop();

        // ── Named loot pools ──────────────────────────────────────────────────
        builder.comment(
                "Named loot pools.",
                "",
                "Format per entry: \"modid:item_id,count,weight\"",
                "  item   : registry name of the item  (e.g. \"minecraft:bread\")",
                "  count  : stack size to spawn        (e.g. 3)",
                "  weight : relative spawn chance      (e.g. 50  — higher = more likely)",
                "",
                "  Example: \"minecraft:bread,3,50\"  (3 bread, weight 50)",
                "",
                "Legacy two-field format \"modid:item_id,weight\" is still supported",
                "and defaults count to 1.",
                "",
                "Built-in pools: common, rare",
                "You can add as many custom pools as you like by adding new sections below.",
                "",
                "Use pool names in targeted deploy commands:",
                "  /braydensurvivezloot deploy minecraft:barrel common",
                "  /braydensurvivezloot deploy force minecraft:chest dungeon_loot",
                "",
                "The 'default' deploy (no block/pool specified) samples ALL pools together."
        ).push("pools");

        registerPool(builder, "common",
                "Common loot pool – high-weight everyday items. Format: item,count,weight",
                Arrays.asList(
                        "minecraft:bread,3,50",
                        "minecraft:apple,2,40",
                        "minecraft:stick,8,35",
                        "minecraft:torch,4,30",
                        "minecraft:cooked_beef,2,25"
                ));

        registerPool(builder, "rare",
                "Rare loot pool – low-weight valuable items. Format: item,count,weight",
                Arrays.asList(
                        "minecraft:golden_apple,1,5",
                        "minecraft:diamond,2,3",
                        "minecraft:enchanted_golden_apple,1,1"
                ));

        registerPool(builder, "dungeon_loot",
                "Example dungeon loot pool – good stuff for chests in dangerous areas. Format: item,count,weight",
                Arrays.asList(
                        "minecraft:iron_sword,1,20",
                        "minecraft:bow,1,15",
                        "minecraft:arrow,16,25",
                        "minecraft:saddle,1,10",
                        "minecraft:name_tag,1,8",
                        "minecraft:music_disc_13,1,3"
                ));

        registerPool(builder, "food",
                "Food-only pool – great for barrels in villages or kitchens. Format: item,count,weight",
                Arrays.asList(
                        "minecraft:bread,4,40",
                        "minecraft:cooked_chicken,2,35",
                        "minecraft:cooked_beef,2,30",
                        "minecraft:cooked_porkchop,2,30",
                        "minecraft:apple,3,25",
                        "minecraft:cookie,8,20",
                        "minecraft:pumpkin_pie,2,15"
                ));

        builder.pop();
    }

    private void registerPool(ForgeConfigSpec.Builder builder, String name, String comment,
                              List<String> defaults) {
        ForgeConfigSpec.ConfigValue<List<? extends String>> val = builder
                .comment(comment)
                .defineList(name, defaults, e -> e instanceof String);
        namedPools.put(name, val);
    }
}

# WorldLoot — braydensurvivez

A Forge mod that deploys custom loot into world containers, with a fully passive
chunk-load system so loot fills gradually as players explore — zero server strain.

---

## Commands  (permission level 2 required)

### Manual deploy (currently loaded chunks only)

| Command | Effect |
|---|---|
| `/braydensurvivezloot deploy` | Fill all eligible loaded containers using all pools |
| `/braydensurvivezloot deploy force` | Same, but re-fill already-populated containers too |
| `/braydensurvivezloot deploy <block> <pool>` | Targeted: only `<block>` type, only `<pool>` |
| `/braydensurvivezloot deploy force <block> <pool>` | Force-targeted variant |

### Global passive system

| Command | Effect |
|---|---|
| `/braydensurvivezloot deploy global <block> <pool>` | Register a persistent assignment |
| `/braydensurvivezloot deploy global list` | Show all active assignments |
| `/braydensurvivezloot remove global <block> <pool>` | Remove an assignment |

### Utility

| Command | Effect |
|---|---|
| `/braydensurvivezloot reset` | Clear filled-tracking data (all containers become eligible again) |
| `/braydensurvivezloot pools` | List configured pool names |

---

## Dimension scoping (v4.4.1.4+)

Both the `deploy` / `deploy force` commands and the passive global chunk-load system now
**only operate in dimensions that currently have at least one player in them**.

- If all players are in the Overworld, only Overworld chunks are scanned/filled.
- If a player enters the Nether, Nether chunks are included while that player is there.
- An empty dimension (nobody in it) is skipped entirely — no scanning, no chunk iteration, zero cost.

This fixes the server freeze/crash that occurred when commands or chunk-load events triggered
bulk scanning across all three dimensions simultaneously.

---

## How the global passive system works

```
/braydensurvivezloot deploy global minecraft:chest dungeon_loot
```

1. **Saves the assignment** (`minecraft:chest → dungeon_loot`) to world data. That's it.  
   No chunk scanning, no immediate bulk work.

2. **From that point forward**, every time Minecraft naturally loads a chunk
   (because a player walked near it, it was force-loaded, etc.), the mod checks
   each block entity in that single chunk:
   - Is it a container? → Does its block type have a global assignment? → Has it been filled before?
   - If all yes/no/no → fill it from the assigned pool, mark it done.

3. This is purely **reactive**. The mod never polls, never walks all chunks,
   never iterates players. Work happens exactly when Minecraft already does work
   (loading a chunk), and is proportional only to the block entities in that
   one chunk.

4. **Assignments survive server restarts** (stored in `worldloot_global_assignments.dat`).

5. To stop filling `minecraft:chest`:
   ```
   /braydensurvivezloot remove global minecraft:chest dungeon_loot
   ```
   Already-filled containers are untouched. New chunks loaded after removal will not fill.

6. Run the command again for the same block to **replace** the pool:
   ```
   /braydensurvivezloot deploy global minecraft:chest rare_loot
   ```

---

## Configuration  (`config/worldloot-server.toml`)

| Key | Default | Description |
|---|---|---|
| `clear_container_before_fill` | `false` | Wipe existing contents before filling |
| `populate_empty_only` | `false` | Only fill containers that are currently empty |
| `ignore_locked_containers` | `true` | Skip locked containers |
| `min_items_per_container` | `3` | Minimum items placed |
| `max_items_per_container` | `10` | Maximum items placed |
| `container_whitelist` | `[]` | Always-allowed block IDs |
| `container_blacklist` | `[]` | Always-skipped block IDs |

---

## Default Loot Pools

Four ready-to-use loot pools are bundled with the mod and written automatically
to `config/worldloot/pools/` on first server start:

| File | Description |
|---|---|
| `overall.json` | General world loot — food most common, junk, ammo, civilian guns, military guns rare |
| `medical.json` | Hospital / clinic loot — heavy medical, gas masks, hazmat, minimal guns |
| `military.json` | Military base loot — rifles, heavy weapons, ammo, attachments, armor |
| `commonsupplies.json` | Civilian survivor finds — food, junk, common guns, military gear extremely rare |

Files are **never overwritten** once created, so you can edit them freely.

---

## Anti-Exploit (Player-Placed Chest Guard)

Once the loot system is active (after you run `/braydensurvivezloot deploy global <block> <pool>`),
any container a player places is **immediately stamped as already-looted** so it can never
receive loot.  This closes the break → replace → loot-refills exploit.

**How it works in plain terms:**

1. Run the deploy global command — the loot system becomes active.
2. All pre-existing chests/barrels in the world are unaffected — they will receive loot normally when opened.
3. From that moment, any chest a player places down is silently marked "already populated."
4. Opening that chest will never trigger loot to spawn.
5. Running `/braydensurvivezloot reset` clears ALL populated marks — including the exploit-guard stamps —
   so everything (including previously player-placed chests) can receive loot again.

No extra command needed to enable this. It turns on automatically the moment a global assignment exists.

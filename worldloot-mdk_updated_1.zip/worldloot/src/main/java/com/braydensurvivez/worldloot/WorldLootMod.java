package com.braydensurvivez.worldloot;

import com.braydensurvivez.worldloot.command.WorldLootCommand;
import com.braydensurvivez.worldloot.config.WorldLootConfig;
import com.braydensurvivez.worldloot.loot.ContainerInteractHandler;
import com.braydensurvivez.worldloot.loot.LootPoolRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(WorldLootMod.MOD_ID)
public class WorldLootMod {

    public static final String MOD_ID = "worldloot";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    /**
     * Shared loot pool registry — loaded once on server start and on /reload.
     * ContainerInteractHandler and DeployEngine both read from this instance.
     * Never call reload() inside a hot path (chunk load, interact event, etc).
     */
    private static final LootPoolRegistry POOL_REGISTRY = new LootPoolRegistry();

    public static LootPoolRegistry getPoolRegistry() {
        return POOL_REGISTRY;
    }

    public WorldLootMod(FMLJavaModLoadingContext context) {

        context.registerConfig(ModConfig.Type.SERVER, WorldLootConfig.SERVER_SPEC, "worldloot-server.toml");

        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);

        // Reload loot pools once when the server is fully started (config is live by then).
        MinecraftForge.EVENT_BUS.addListener(this::onServerStarted);

        // Reload pools again if the operator runs /reload (ModConfig reloads fire this event).
        MinecraftForge.EVENT_BUS.addListener(this::onConfigReload);

        // Loot generation: fires only when a player actually right-clicks a container.
        // No chunk scanning, no polling, no bulk iteration.
        MinecraftForge.EVENT_BUS.addListener(this::onRightClickBlock);

        // Anti-exploit: stamp player-placed containers as already-populated
        // so the loot system skips them. Only active once a global assignment exists.
        MinecraftForge.EVENT_BUS.addListener(this::onBlockPlace);

        LOGGER.info("[WorldLoot] Mod initialised.");
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        WorldLootCommand.register(event.getDispatcher());
        LOGGER.info("[WorldLoot] Commands registered.");
    }

    private void onServerStarted(ServerStartedEvent event) {
        POOL_REGISTRY.reload();
        LOGGER.info("[WorldLoot] Loot pools loaded: {}", POOL_REGISTRY.getPoolNames());
    }

    private void onConfigReload(net.minecraftforge.fml.event.config.ModConfigEvent.Reloading event) {
        if (event.getConfig().getModId().equals(MOD_ID)) {
            POOL_REGISTRY.reload();
            LOGGER.info("[WorldLoot] Config reloaded — loot pools refreshed: {}", POOL_REGISTRY.getPoolNames());
        }
    }

    private void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        ContainerInteractHandler.onRightClickBlock(event);
    }

    private void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        ContainerInteractHandler.onBlockPlace(event);
    }
}

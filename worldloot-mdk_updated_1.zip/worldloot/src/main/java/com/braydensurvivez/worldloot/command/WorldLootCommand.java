package com.braydensurvivez.worldloot.command;

import com.braydensurvivez.worldloot.data.GlobalAssignmentData;
import com.braydensurvivez.worldloot.loot.DeployEngine;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;

import java.util.Map;

/**
 * Command layout:
 *
 *   /braydensurvivezloot deploy                            – fill all loaded containers (all pools)
 *   /braydensurvivezloot deploy force                      – same, re-fill already-populated ones too
 *   /braydensurvivezloot deploy <block> <pool>             – targeted, currently loaded chunks
 *   /braydensurvivezloot deploy force <block> <pool>       – force-targeted
 *   /braydensurvivezloot deploy global <block> <pool>      – register passive chunk-load assignment
 *   /braydensurvivezloot deploy global list                – list all active global assignments
 *
 *   /braydensurvivezloot remove global <block> <pool>      – remove a specific global assignment
 *
 *   /braydensurvivezloot reset                             – clear populated-tracking data
 *   /braydensurvivezloot pools                             – list configured pool names
 */
public class WorldLootCommand {

    private static DeployEngine engine;

    private static DeployEngine getEngine() {
        if (engine == null) engine = new DeployEngine();
        return engine;
    }

    // Tab-complete: pool names from config
    private static final SuggestionProvider<CommandSourceStack> SUGGEST_POOLS =
            (ctx, builder) -> SharedSuggestionProvider.suggest(getEngine().getPoolNames(), builder);

    // Tab-complete: block IDs that already have a global assignment
    private static final SuggestionProvider<CommandSourceStack> SUGGEST_ASSIGNED_BLOCKS =
            (ctx, builder) -> {
                MinecraftServer server = ctx.getSource().getServer();
                if (server == null) return builder.buildFuture();
                return SharedSuggestionProvider.suggest(
                        GlobalAssignmentData.get(server.overworld()).getAll().keySet(), builder);
            };

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("braydensurvivezloot")
                .requires(src -> src.hasPermission(2))

                // ── deploy ────────────────────────────────────────────────
                .then(Commands.literal("deploy")

                    // deploy global …
                    .then(Commands.literal("global")

                        // deploy global list
                        .then(Commands.literal("list")
                            .executes(WorldLootCommand::globalList))

                        // deploy global <block> <pool>
                        .then(Commands.argument("block", StringArgumentType.string())
                            .then(Commands.argument("pool", StringArgumentType.string())
                                .suggests(SUGGEST_POOLS)
                                .executes(WorldLootCommand::deployGlobal))))

                    // deploy force [<block> <pool>]
                    .then(Commands.literal("force")
                        .then(Commands.argument("block", StringArgumentType.string())
                            .then(Commands.argument("pool", StringArgumentType.string())
                                .suggests(SUGGEST_POOLS)
                                .executes(WorldLootCommand::deployTargetedForce)))
                        .executes(WorldLootCommand::deployForce))

                    // deploy <block> <pool>
                    .then(Commands.argument("block", StringArgumentType.string())
                        .then(Commands.argument("pool", StringArgumentType.string())
                            .suggests(SUGGEST_POOLS)
                            .executes(WorldLootCommand::deployTargeted)))

                    // deploy  (no args)
                    .executes(WorldLootCommand::deploy))

                // ── remove ────────────────────────────────────────────────
                .then(Commands.literal("remove")

                    // remove global <block> <pool>
                    .then(Commands.literal("global")
                        .then(Commands.argument("block", StringArgumentType.string())
                            .suggests(SUGGEST_ASSIGNED_BLOCKS)
                            .then(Commands.argument("pool", StringArgumentType.string())
                                .suggests(SUGGEST_POOLS)
                                .executes(WorldLootCommand::removeGlobal)))))

                // ── reset ─────────────────────────────────────────────────
                .then(Commands.literal("reset")
                    .executes(WorldLootCommand::reset))

                // ── pools ─────────────────────────────────────────────────
                .then(Commands.literal("pools")
                    .executes(WorldLootCommand::listPools))
        );
    }

    // ── Manual deploy ──────────────────────────────────────────────────────────

    private static int deploy(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        src.sendSuccess(() -> Component.literal("[WorldLoot] Starting deployment scan…"), true);
        DeployEngine.DeployResult r = getEngine().deploy(src.getServer(), false);
        src.sendSuccess(() -> Component.literal(formatResult(r, false, null, null)), true);
        return 1;
    }

    private static int deployForce(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        src.sendSuccess(() -> Component.literal("[WorldLoot] Starting FORCE deployment scan…"), true);
        DeployEngine.DeployResult r = getEngine().deploy(src.getServer(), true);
        src.sendSuccess(() -> Component.literal(formatResult(r, true, null, null)), true);
        return 1;
    }

    private static int deployTargeted(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();
        if (!validatePool(src, pool)) return 0;
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot] Targeting block='" + block + "' pool='" + pool + "'…"), true);
        DeployEngine.DeployResult r = getEngine().deployTargeted(src.getServer(), false, block, pool);
        src.sendSuccess(() -> Component.literal(formatResult(r, false, block, pool)), true);
        return 1;
    }

    private static int deployTargetedForce(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();
        if (!validatePool(src, pool)) return 0;
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot] FORCE targeting block='" + block + "' pool='" + pool + "'…"), true);
        DeployEngine.DeployResult r = getEngine().deployTargeted(src.getServer(), true, block, pool);
        src.sendSuccess(() -> Component.literal(formatResult(r, true, block, pool)), true);
        return 1;
    }

    // ── Global assignment (passive chunk-load system) ──────────────────────────

    /**
     * /braydensurvivezloot deploy global <block> <pool>
     *
     * Registers a persistent assignment. From this point forward, whenever a chunk
     * loads that contains a container of type <block> that hasn't been filled yet,
     * ContainerInteractHandler will fill it when a player opens the container.
     *
     * No immediate scanning. No bulk work. The command simply saves the assignment
     * and returns. Filling happens when a player right-clicks an assigned container.
     *
     * Running the command again for the same <block> REPLACES the pool.
     */
    private static int deployGlobal(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();

        if (!validatePool(src, pool)) return 0;

        GlobalAssignmentData data = GlobalAssignmentData.get(src.getServer().overworld());
        String previous = data.getPool(block);
        data.assign(block, pool);

        if (previous != null) {
            src.sendSuccess(() -> Component.literal(String.format(
                    "[WorldLoot] Global assignment UPDATED: '%s' was '%s', now '%s'. " +
                    "Containers will be filled from '%s' as chunks load.",
                    block, previous, pool, pool)), true);
        } else {
            src.sendSuccess(() -> Component.literal(String.format(
                    "[WorldLoot] Global assignment SET: '%s' → '%s'. " +
                    "Any '%s' container in a newly loaded chunk will be filled from '%s'.",
                    block, pool, block, pool)), true);
        }
        return 1;
    }

    /**
     * /braydensurvivezloot remove global <block> <pool>
     *
     * Removes the global assignment for <block>. The <pool> argument is required
     * and must match the currently assigned pool — this prevents accidentally
     * removing the wrong assignment. Already-filled containers are not affected.
     */
    private static int removeGlobal(CommandContext<CommandSourceStack> ctx) {
        String block = StringArgumentType.getString(ctx, "block");
        String pool  = StringArgumentType.getString(ctx, "pool");
        CommandSourceStack src = ctx.getSource();

        GlobalAssignmentData data = GlobalAssignmentData.get(src.getServer().overworld());
        String current = data.getPool(block);

        if (current == null) {
            src.sendFailure(Component.literal(String.format(
                    "[WorldLoot] No global assignment exists for '%s'.", block)));
            return 0;
        }

        if (!current.equalsIgnoreCase(pool.trim())) {
            src.sendFailure(Component.literal(String.format(
                    "[WorldLoot] Pool mismatch: '%s' is currently assigned to '%s', not '%s'. " +
                    "Use /braydensurvivezloot deploy global list to see active assignments.",
                    block, current, pool)));
            return 0;
        }

        data.remove(block);
        src.sendSuccess(() -> Component.literal(String.format(
                "[WorldLoot] Global assignment REMOVED: '%s' → '%s'. " +
                "Chunks loaded from now on will not fill '%s' containers. " +
                "Already-filled containers are unchanged.",
                block, pool, block)), true);
        return 1;
    }

    /**
     * /braydensurvivezloot deploy global list
     */
    private static int globalList(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        Map<String, String> all = GlobalAssignmentData.get(src.getServer().overworld()).getAll();
        if (all.isEmpty()) {
            src.sendSuccess(() -> Component.literal(
                    "[WorldLoot] No global assignments active. " +
                    "Use: /braydensurvivezloot deploy global <block> <pool>"), false);
        } else {
            StringBuilder sb = new StringBuilder("[WorldLoot] Active global assignments (").append(all.size()).append("):\n");
            all.forEach((b, p) -> sb.append("  ").append(b).append("  →  ").append(p).append("\n"));
            sb.append("Use /braydensurvivezloot remove global <block> <pool> to remove one.");
            src.sendSuccess(() -> Component.literal(sb.toString().trim()), false);
        }
        return 1;
    }

    // ── Reset ──────────────────────────────────────────────────────────────────

    private static int reset(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        getEngine().reset(src.getServer());
        src.sendSuccess(() -> Component.literal(
                "[WorldLoot] Tracking cleared. All containers eligible for next deploy " +
                "and for global chunk-load fills."), true);
        return 1;
    }

    // ── List pools ─────────────────────────────────────────────────────────────

    private static int listPools(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        String names = String.join(", ", getEngine().getPoolNames());
        src.sendSuccess(() -> Component.literal("[WorldLoot] Available pools: " + names), false);
        return 1;
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private static boolean validatePool(CommandSourceStack src, String pool) {
        if (!getEngine().getPoolNames().contains(pool)) {
            src.sendFailure(Component.literal(
                    "[WorldLoot] Unknown pool '" + pool + "'. Use /braydensurvivezloot pools to list available pools."));
            return false;
        }
        return true;
    }

    private static String formatResult(DeployEngine.DeployResult r, boolean force,
                                       String block, String pool) {
        String prefix = force ? "Force deploy" : "Deploy";
        String target = (block != null) ? " [" + block + " / " + pool + "]" : "";
        return String.format(
                "[WorldLoot] %s%s complete. Dims:%d Chunks:%d Found:%d Populated:%d Skipped:%d BadIDs:%d",
                prefix, target,
                r.dimensionsScanned, r.chunksScanned,
                r.containersFound, r.containersPopulated,
                r.containersSkipped, r.invalidRegistryEntries);
    }
}

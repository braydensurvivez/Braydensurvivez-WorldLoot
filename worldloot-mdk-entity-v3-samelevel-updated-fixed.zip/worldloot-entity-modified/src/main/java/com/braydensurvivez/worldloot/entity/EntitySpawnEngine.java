package com.braydensurvivez.worldloot.entity;

import com.braydensurvivez.worldloot.WorldLootMod;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;
import java.util.Optional;
import java.util.Random;

/**
 * Picks a random entity from a named EntitySpawnPool and spawns it in the world
 * at a position some chunks away from a randomly selected online player.
 *
 * The min/max values in EntitySpawnRule are NOT distances — they are the
 * minimum and maximum total loaded chunk counts required for a spawn rule to
 * fire. Once that chunk-count quota is reached the tick handler calls this
 * engine, which then places the entity at the configured chunk distance from
 * a random player.
 *
 * Spawn constraints (all must pass):
 *   - Solid ground beneath the spawn block
 *   - Two air blocks tall at spawn position (feet + head)
 *   - 5×5 horizontal area clear at foot level and head level
 *   - Sky light level > 0 (entity must spawn in natural/sky light)
 *
 * Returns a SpawnResult describing what happened (used by the debug system
 * and by manual /entity spawn command feedback).
 */
public class EntitySpawnEngine {

    /**
     * Default spawn chunk distance range used when no explicit distance is
     * provided (e.g. from automatic tick-handler spawns or legacy calls).
     */
    public static final int DEFAULT_SPAWN_CHUNK_OFFSET_MIN = 3;
    public static final int DEFAULT_SPAWN_CHUNK_OFFSET_MAX = 6;

    /**
     * Radius of the horizontal clear-space check around the spawn position.
     * A value of 2 means we check a 5×5 area (from -2 to +2 on each axis).
     */
    private static final int CLEAR_SPACE_RADIUS = 2;

    /**
     * Duration of the Glowing effect applied to debug-mode spawns, in ticks.
     * 6000 ticks = 5 minutes.
     */
    private static final int DEBUG_GLOW_DURATION_TICKS = 6000;

    private static final Random RNG = new Random();

    // ── Result record ──────────────────────────────────────────────────────────

    public static class SpawnResult {
        public final boolean success;
        /** Entity that was spawned, or null on failure. */
        public final Entity  entity;
        /** ResourceLocation of the entity type picked. */
        public final ResourceLocation entityId;
        /** Pool entry that was selected. */
        public final EntitySpawnEntry entry;
        /** Pool the entry came from. */
        public final EntitySpawnPool  pool;
        /** World position of the spawn. */
        public final BlockPos         spawnPos;
        /** Player the spawn was offset from. */
        public final ServerPlayer     nearestPlayer;
        /** Chunk distance from the player (in chunk units). */
        public final int              chunkDistance;
        /** Human-readable failure reason, or null on success. */
        public final String           failReason;

        private SpawnResult(boolean success, Entity entity, ResourceLocation entityId,
                            EntitySpawnEntry entry, EntitySpawnPool pool,
                            BlockPos spawnPos, ServerPlayer nearestPlayer,
                            int chunkDistance, String failReason) {
            this.success       = success;
            this.entity        = entity;
            this.entityId      = entityId;
            this.entry         = entry;
            this.pool          = pool;
            this.spawnPos      = spawnPos;
            this.nearestPlayer = nearestPlayer;
            this.chunkDistance = chunkDistance;
            this.failReason    = failReason;
        }

        public static SpawnResult fail(String reason) {
            return new SpawnResult(false, null, null, null, null, null, null, 0, reason);
        }

        public static SpawnResult ok(Entity entity, ResourceLocation entityId,
                                     EntitySpawnEntry entry, EntitySpawnPool pool,
                                     BlockPos pos, ServerPlayer player, int chunkDist) {
            return new SpawnResult(true, entity, entityId, entry, pool, pos, player, chunkDist, null);
        }
    }

    // ── Public API ─────────────────────────────────────────────────────────────

    /**
     * Attempt to spawn one entity from poolName in level using default chunk distance.
     * If debugMode is true, the Glowing effect is applied to the spawned mob.
     */
    public static SpawnResult spawnFromPool(ServerLevel level,
                                            EntitySpawnPoolRegistry registry,
                                            String poolName,
                                            boolean debugMode) {
        return spawnFromPool(level, registry, poolName, debugMode,
                DEFAULT_SPAWN_CHUNK_OFFSET_MIN, DEFAULT_SPAWN_CHUNK_OFFSET_MAX);
    }

    /**
     * Attempt to spawn one entity from poolName in level, with an explicit
     * chunk distance range.
     *
     * @param chunkMin minimum chunk distance from the player (inclusive)
     * @param chunkMax maximum chunk distance from the player (inclusive)
     */
    public static SpawnResult spawnFromPool(ServerLevel level,
                                            EntitySpawnPoolRegistry registry,
                                            String poolName,
                                            boolean debugMode,
                                            int chunkMin,
                                            int chunkMax) {
        EntitySpawnPool pool = registry.getPool(poolName);
        if (pool == null || pool.isEmpty()) {
            return SpawnResult.fail("Pool '" + poolName + "' is null or empty");
        }

        List<ServerPlayer> players = level.getServer().getPlayerList().getPlayers();
        if (players.isEmpty()) {
            return SpawnResult.fail("No players online");
        }
        ServerPlayer target = players.get(RNG.nextInt(players.size()));

        // Weighted-random pick from pool
        EntitySpawnEntry entry = pool.pick(RNG);
        if (entry == null) {
            return SpawnResult.fail("Pool pick returned null (pool may be empty)");
        }

        EntityType<?> entityType = ForgeRegistries.ENTITY_TYPES.getValue(entry.entityId);
        if (entityType == null) {
            return SpawnResult.fail("Entity type '" + entry.entityId + "' not found in registry");
        }

        // Find a valid spawn position near the player in a loaded chunk
        int[] chunkDistHolder = {0};
        Optional<BlockPos> posOpt = findOffsetSpawnPos(level, target, chunkDistHolder, chunkMin, chunkMax);
        if (posOpt.isEmpty()) {
            return SpawnResult.fail("No valid spawn position found near "
                    + target.getName().getString()
                    + " after 32 attempts (requires natural sky light and 5x5 clear space)");
        }

        BlockPos pos = posOpt.get();
        Entity entity = entityType.create(level);
        if (entity == null) {
            return SpawnResult.fail("EntityType.create() returned null for '" + entry.entityId + "'");
        }

        entity.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);

        if (entity instanceof Mob mob) {
            mob.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.EVENT, null, null);
        }

        boolean added = level.addFreshEntity(entity);
        if (!added) {
            return SpawnResult.fail("addFreshEntity() returned false for '" + entry.entityId + "' at " + pos);
        }

        // ── Debug: apply Glowing effect ───────────────────────────────────────
        if (debugMode && entity instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(
                    MobEffects.GLOWING,
                    DEBUG_GLOW_DURATION_TICKS,
                    0,
                    false,
                    true,
                    true
            ));
        }

        return SpawnResult.ok(entity, entry.entityId, entry, pool, pos, target, chunkDistHolder[0]);
    }

    /**
     * Legacy overload without debugMode — defaults to no glow, default distance.
     */
    public static SpawnResult spawnFromPool(ServerLevel level,
                                            EntitySpawnPoolRegistry registry,
                                            String poolName) {
        return spawnFromPool(level, registry, poolName, false);
    }

    // ── Position finding ───────────────────────────────────────────────────────

    /**
     * How many blocks above and below the player's Y level to search for a
     * valid ground position.
     */
    private static final int VERTICAL_SEARCH_RANGE = 16;

    /**
     * Finds a valid ground-level position between chunkMin–chunkMax chunks from
     * the player, at approximately the same Y level as the player.
     *
     * Additional constraints vs the base version:
     *   - Sky light level > 0 (natural light required)
     *   - 5×5 horizontal area clear at both foot and head height
     */
    private static Optional<BlockPos> findOffsetSpawnPos(ServerLevel level,
                                                          ServerPlayer player,
                                                          int[] chunkDistHolder,
                                                          int chunkMin,
                                                          int chunkMax) {
        Vec3 playerPos   = player.position();
        int playerChunkX = (int) playerPos.x >> 4;
        int playerChunkZ = (int) playerPos.z >> 4;
        int playerY      = (int) Math.floor(playerPos.y);

        int range = Math.max(0, chunkMax - chunkMin);

        for (int attempt = 0; attempt < 32; attempt++) {
            double angle         = RNG.nextDouble() * 2 * Math.PI;
            int    chunkDistance = chunkMin + (range == 0 ? 0 : RNG.nextInt(range + 1));

            int targetChunkX = playerChunkX + (int) Math.round(Math.cos(angle) * chunkDistance);
            int targetChunkZ = playerChunkZ + (int) Math.round(Math.sin(angle) * chunkDistance);

            net.minecraft.world.level.chunk.LevelChunk chunk;
            try {
                chunk = level.getChunk(targetChunkX, targetChunkZ);
            } catch (Exception e) {
                WorldLootMod.LOGGER.debug(
                        "[WorldLoot/EntitySpawn] Chunk ({},{}) threw during access: {}",
                        targetChunkX, targetChunkZ, e.getMessage());
                continue;
            }

            if (chunk == null) continue;

            int blockX = (targetChunkX << 4) + RNG.nextInt(16);
            int blockZ = (targetChunkZ << 4) + RNG.nextInt(16);

            BlockPos groundPos = findGroundNearY(level, blockX, blockZ, playerY);
            if (groundPos == null) continue;

            chunkDistHolder[0] = chunkDistance;
            return Optional.of(groundPos);
        }

        return Optional.empty();
    }

    /**
     * Scans from (blockX, startY, blockZ) downward then upward within
     * VERTICAL_SEARCH_RANGE blocks to find a position that passes
     * {@link #isValidSpawnPos}.
     */
    private static BlockPos findGroundNearY(ServerLevel level, int blockX, int blockZ, int startY) {
        int minY = startY - VERTICAL_SEARCH_RANGE;
        int maxY = startY + VERTICAL_SEARCH_RANGE;

        int worldMinY = level.getMinBuildHeight() + 1;
        int worldMaxY = level.getMaxBuildHeight() - 2;
        minY = Math.max(minY, worldMinY);
        maxY = Math.min(maxY, worldMaxY);

        for (int y = startY; y >= minY; y--) {
            BlockPos candidate = new BlockPos(blockX, y, blockZ);
            if (isValidSpawnPos(level, candidate)) return candidate;
        }

        for (int y = startY + 1; y <= maxY; y++) {
            BlockPos candidate = new BlockPos(blockX, y, blockZ);
            if (isValidSpawnPos(level, candidate)) return candidate;
        }

        return null;
    }

    /**
     * Returns true when pos is a fully valid spawn slot:
     *
     *   1. Solid block directly below (ground).
     *   2. Air at foot level (pos) and head level (pos.above()).
     *   3. Sky light level > 0 at foot level — entity must be in natural light
     *      (sky-lit, not just torch-lit).
     *   4. 5×5 horizontal clear space: every block in the [-2, +2] square
     *      at both foot height and head height must be air.
     */
    private static boolean isValidSpawnPos(ServerLevel level, BlockPos pos) {
        // 1. Solid ground
        BlockState ground = level.getBlockState(pos.below());
        if (!ground.isSolid()) return false;

        // 2. Two air blocks at foot + head
        if (!level.getBlockState(pos).isAir()) return false;
        if (!level.getBlockState(pos.above()).isAir()) return false;

        // 3. Natural (sky) light required — sky light level must be > 0
        if (level.getBrightness(LightLayer.SKY, pos) <= 0) return false;

        // 4. 5×5 horizontal clear space (foot + head rows)
        for (int dx = -CLEAR_SPACE_RADIUS; dx <= CLEAR_SPACE_RADIUS; dx++) {
            for (int dz = -CLEAR_SPACE_RADIUS; dz <= CLEAR_SPACE_RADIUS; dz++) {
                if (dx == 0 && dz == 0) continue; // centre already checked above
                BlockPos foot = pos.offset(dx, 0, dz);
                BlockPos head = pos.offset(dx, 1, dz);
                if (!level.getBlockState(foot).isAir()) return false;
                if (!level.getBlockState(head).isAir()) return false;
            }
        }

        return true;
    }
}
